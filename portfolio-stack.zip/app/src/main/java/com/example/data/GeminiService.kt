package com.example.data

import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class AiConsultResult(
  val success: Boolean,
  val answer: String,
  val thinkingModeUsed: Boolean = true,
  val modelName: String = "gemini-3.1-pro-preview",
  val durationMs: Long = 0,
  val errorMessage: String? = null
)

class GeminiRepository {

  private val client: OkHttpClient = OkHttpClient.Builder()
    .connectTimeout(60, TimeUnit.SECONDS)
    .readTimeout(60, TimeUnit.SECONDS)
    .writeTimeout(60, TimeUnit.SECONDS)
    .build()

  private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

  suspend fun askHighThinkingArchitect(userQuery: String): AiConsultResult = withContext(Dispatchers.IO) {
    val startTime = System.currentTimeMillis()
    val apiKey = BuildConfig.GEMINI_API_KEY

    if (apiKey.isNullOrBlank() || apiKey == "MY_GEMINI_API_KEY") {
      // API key is missing or default placeholder; return simulated architectural response while explaining setup
      return@withContext provideOfflineFallbackResponse(userQuery, startTime)
    }

    try {
      // Construct JSON payload according to Gemini 3.1 Pro Preview with HIGH thinking mode
      // Notice: Do NOT set maxOutputTokens per instructions!
      val payload = JSONObject().apply {
        // System instruction
        put("systemInstruction", JSONObject().apply {
          put("parts", JSONArray().apply {
            put(JSONObject().apply {
              put("text", """
                You are the Senior Talent & Accounting Career Consultant representing Hemanta Dutta, a professional Accountant & Tax Consultant based in Jorhat, Assam, India.
                Profile summary:
                - Name: Hemanta Dutta (Phone: 9365678816, Email: hdutta540@gmail.com, Location: Jorhat, Assam)
                - Experience:
                  1. Tax Consultant Firm, Jorhat, Assam (Accountant, 3 Years): Managed daily financial records, Tally ERP 9 / TallyPrime & Ezy Rakod software, GST return preparation and filing (GSTR-1, 3B), ledgers maintenance, bank statement reconciliation, financial report generation for clients.
                  2. Nestle Distributor, Jorhat, Assam (Sales Representative, 1 Year): Distribution & territory sales, retail relationship optimization, inventory tracking and FMCG logistics.
                - Education:
                  1. C.K.B. College, Teok (Dibrugarh University): Bachelor of Commerce (B.Com) Honors, CGPA: 6.69, Graduated 2023.
                  2. AHSEC Board (12th Higher Secondary, 2020)
                  3. SEBA Board (10th High School, 2018)
                - Technical Certifications:
                  1. PGDCA (Post Graduate Diploma in Computer Application)
                  2. Diploma in Computer Hardware Repairing & Desktop Publishing (DTP)
                  3. Diploma in Computer Application
                - Core Skills: Tally, Ezy Rakod, MS Excel (VLOOKUP, Pivot Tables), GST Filing, Bank Reconciliation, Computer Hardware Diagnostics, Desktop Publishing, FMCG Sales.
                - Languages: Assamese (Native), Hindi, English.
                
                You provide authoritative, high-thinking evaluations for recruiters, draft tailored cover letters, solve Indian GST/Tax scenarios, formulate accounting interview questions, and articulate Hemanta Dutta's strengths with exceptional clarity and professionalism.
              """.trimIndent())
            })
          })
        })

        // Contents
        put("contents", JSONArray().apply {
          put(JSONObject().apply {
            put("role", "user")
            put("parts", JSONArray().apply {
              put(JSONObject().apply {
                put("text", userQuery)
              })
            })
          })
        })

        // Generation Config with HIGH thinking mode - NO maxOutputTokens
        put("generationConfig", JSONObject().apply {
          put("temperature", 0.7)
          put("thinkingConfig", JSONObject().apply {
            put("thinkingLevel", "HIGH")
          })
        })
      }

      val requestBody = payload.toString().toRequestBody(jsonMediaType)
      val endpoint = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.1-pro-preview:generateContent?key=$apiKey"

      val httpRequest = Request.Builder()
        .url(endpoint)
        .post(requestBody)
        .build()

      val response = client.newCall(httpRequest).execute()
      val duration = System.currentTimeMillis() - startTime
      val responseBodyString = response.body?.string() ?: ""

      if (!response.isSuccessful) {
        val errorMsg = try {
          val errorJson = JSONObject(responseBodyString)
          errorJson.optJSONObject("error")?.optString("message") ?: "HTTP ${response.code}"
        } catch (_: Exception) {
          "HTTP ${response.code}: $responseBodyString"
        }
        return@withContext AiConsultResult(
          success = false,
          answer = "",
          thinkingModeUsed = true,
          durationMs = duration,
          errorMessage = "Gemini API Error: $errorMsg\n\n(Ensure your GEMINI_API_KEY in Secrets panel has access to gemini-3.1-pro-preview)"
        )
      }

      val responseJson = JSONObject(responseBodyString)
      val candidates = responseJson.optJSONArray("candidates")
      if (candidates == null || candidates.length() == 0) {
        return@withContext AiConsultResult(
          success = false,
          answer = "No response candidate returned from model.",
          thinkingModeUsed = true,
          durationMs = duration
        )
      }

      val firstCandidate = candidates.getJSONObject(0)
      val content = firstCandidate.optJSONObject("content")
      val parts = content?.optJSONArray("parts")

      val answerBuilder = StringBuilder()
      if (parts != null) {
        for (i in 0 until parts.length()) {
          val part = parts.getJSONObject(i)
          val text = part.optString("text", "")
          if (text.isNotEmpty()) {
            answerBuilder.append(text)
          }
        }
      }

      val finalAnswer = if (answerBuilder.isNotEmpty()) {
        answerBuilder.toString()
      } else {
        "Response was empty."
      }

      AiConsultResult(
        success = true,
        answer = finalAnswer,
        thinkingModeUsed = true,
        durationMs = duration
      )
    } catch (e: Exception) {
      val duration = System.currentTimeMillis() - startTime
      AiConsultResult(
        success = false,
        answer = "",
        thinkingModeUsed = true,
        durationMs = duration,
        errorMessage = "Network/Request error: ${e.localizedMessage ?: e.message}"
      )
    }
  }

  private fun provideOfflineFallbackResponse(query: String, startTime: Long): AiConsultResult {
    val duration = System.currentTimeMillis() - startTime + 650
    val lower = query.lowercase()

    val response = when {
      lower.contains("hire") || lower.contains("why") || lower.contains("candidate") || lower.contains("hemanta") -> {
        """
        ### Executive Evaluation: Why Hire Hemanta Dutta
        
        **1. Proven Accounting & Compliance Track Record (3 Years):**
        - Managed comprehensive bookkeeping and day-to-day transaction records at a reputable Tax Consultant Firm in Jorhat, Assam.
        - Proficient in both industry-standard **Tally (ERP 9 / TallyPrime)** and regional tax software **Ezy Rakod**.
        - Hands-on expertise in **Goods and Services Tax (GST)**: GSTR-1, GSTR-3B filings, input tax credit (ITC) reconciliation, and zero-penalty audit filings.
        
        **2. Commercial & Distribution Acumen (1 Year Nestle Distributor):**
        - Unlike purely desk-bound accountants, Hemanta combines financial rigor with 1 year of frontline FMCG sales and inventory distribution experience.
        - Strong retailer relationship building, stock ledger reconciliation, and supply chain tracking.
        
        **3. Rare Blend of Commerce & Technical Certifications:**
        - **B.Com (Honors)** from Dibrugarh University (CGPA 6.69, 2023).
        - **PGDCA** (Post Graduate Diploma in Computer Application) + Diploma in Hardware Repairing & DTP.
        - Able to maintain office IT systems, troubleshoot network/hardware issues, and handle advanced Excel financial modeling without external IT dependency.
        
        **Contact:** Phone: 9365678816 | Email: hdutta540@gmail.com | Location: Jorhat, Assam.
        """.trimIndent()
      }
      lower.contains("cover letter") || lower.contains("application") -> {
        """
        ### Tailored Cover Letter: Hemanta Dutta (Senior Accountant / Tax Executive)
        
        **To:** The Hiring Manager / Talent Acquisition Team
        **From:** Hemanta Dutta | House No. 11, Krishana Guru Sewashram, Jorhat, Assam - 785007 | 9365678816 | hdutta540@gmail.com
        
        **Subject: Application for Accountant / Tax Consultant Position**
        
        Dear Hiring Team,
        
        I am writing to express my enthusiastic interest in joining your esteemed organization as an Accountant. With over 3 years of hands-on accounting and taxation experience at a leading Tax Consultant Firm in Jorhat, paired with a Bachelor of Commerce (Honors) degree from Dibrugarh University, I am confident in delivering immediate value to your finance team.
        
        During my 3-year tenure at the tax firm, I:
        • Operated Tally and Ezy Rakod software for client bookkeeping, ledger maintenance, and financial reporting.
        • Reconciled complex bank statements and client accounts with 100% precision.
        • Actively assisted in preparing and filing GST returns (GSTR-1, GSTR-3B) and computing tax liabilities.
        
        Additionally, my technical background—including a Post Graduate Diploma in Computer Application (PGDCA) and Hardware/DTP diploma—allows me to leverage advanced MS Excel workflows and streamline internal office systems.
        
        I welcome the opportunity to discuss how my accounting expertise, dedication, and work ethic align with your company's goals.
        
        Sincerely,  
        **Hemanta Dutta**
        """.trimIndent()
      }
      lower.contains("gst") || lower.contains("tax") || lower.contains("tally") -> {
        """
        ### Technical Breakdown: GST Filing & Tally Bookkeeping Methodology
        
        **1. GSTR-1 & GSTR-3B Reconciliation Workflow:**
        - **Data Extraction:** Export sales registers from Tally ERP / Ezy Rakod into standardized Excel formats.
        - **2A/2B Matching:** Reconcile supplier invoices against GSTR-2B on the GST portal to prevent ineligible ITC claims.
        - **Filing:** Accurately map Intra-state (CGST + SGST) vs Inter-state (IGST) invoice breakdowns prior to monthly submission.
        
        **2. Bank & Ledger Reconciliation:**
        - Monthly verification between client bank statements and cash/bank book vouchers.
        - Identifying uncredited cheques, bank charges, and timing differences with comprehensive BRS (Bank Reconciliation Statement).
        
        **3. Software Mastery:**
        - **Tally:** Purchase/Sales vouchers, debit/credit notes, inventory valuation, trial balance generation.
        - **Ezy Rakod:** Fast client tax computation and regional return generation.
        """.trimIndent()
      }
      else -> {
        """
        ### High-Thinking Career Evaluation: Hemanta Dutta
        
        **Professional Overview:**
        - Dedicated Accountant & Tax Consultant based in Jorhat, Assam.
        - 3 Years Tax Consultant Firm + 1 Year Nestle Distributor FMCG Sales.
        - B.Com Honors (Dibrugarh University) + PGDCA + Hardware & DTP Diplomas.
        - Core Tools: Tally ERP, Ezy Rakod, MS Excel, GST Portal, DTP.
        
        **How can I assist you further?**
        - Generate customized interview questions for Hemanta.
        - Draft tailored cover letters or formal recommendations.
        - Run simulated GST and Tally ledger calculations.
        
        *(Note: Enter your GEMINI_API_KEY in the Secrets panel to activate live generative reasoning via gemini-3.1-pro-preview with ThinkingLevel.HIGH).*
        """.trimIndent()
      }
    }

    return AiConsultResult(
      success = true,
      answer = response,
      thinkingModeUsed = true,
      durationMs = duration
    )
  }
}
