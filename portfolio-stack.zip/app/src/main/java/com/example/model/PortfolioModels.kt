package com.example.model

data class StackCategory(
  val id: String,
  val title: String,
  val subtitle: String,
  val iconName: String,
  val items: List<StackItem>
)

data class StackItem(
  val technology: String,
  val purpose: String,
  val codeSample: String,
  val metrics: String,
  val tag: String,
  val keyFeatures: List<String>
)

object PortfolioData {
  const val POSITIONING_STATEMENT = 
    "Premium personal portfolio development — combining strong visual design, immersive 3D presentation, smooth motion, responsive UX, and modern frontend engineering to create a memorable digital first impression."

  const val STACK_INTRO = 
    "A modern, interactive portfolio experience focused on premium visual design, smooth motion, responsive development, and high-performance delivery."

  val categories = listOf(
    StackCategory(
      id = "frontend",
      title = "Frontend Development",
      subtitle = "Modern, reactive UI foundations",
      iconName = "Code",
      items = listOf(
        StackItem(
          technology = "React",
          purpose = "Component-based UI architecture and interactive portfolio sections.",
          codeSample = """
            // Interactive 3D Hero Section Container
            export const HeroShowcase = () => {
              const [rotation, setRotation] = useState({ x: 0, y: 0 });
              return (
                <section className="relative h-screen flex items-center justify-center overflow-hidden">
                  <Canvas3DModel yaw={rotation.y} pitch={rotation.x} />
                  <HeroHeadline text="Crafting High-Performance Experiences" />
                </section>
              );
            };
          """.trimIndent(),
          metrics = "React 19 Server Components ready • 0 layout shifts",
          tag = "Architecture",
          keyFeatures = listOf(
            "Modular component lifecycle",
            "Suspense-driven asset streaming",
            "Zero hydration mismatch architecture"
          )
        ),
        StackItem(
          technology = "JavaScript / TypeScript",
          purpose = "Application logic, interactions, and maintainable frontend structure.",
          codeSample = """
            interface PortfolioProject {
              id: string;
              title: string;
              category: '3D' | 'Fullstack' | 'DesignSystem';
              metrics: { fps: number; bundleKb: number };
            }
            
            export const calculateParallax = (scrollY: number, depth: number): number => {
              return scrollY * (depth * 0.15);
            };
          """.trimIndent(),
          metrics = "100% strict TypeScript typing • Zero any types",
          tag = "Type Safety",
          keyFeatures = listOf(
            "Type-safe navigation & API contracts",
            "Functional state composition",
            "Immutable data pipelines"
          )
        ),
        StackItem(
          technology = "HTML5 & CSS3",
          purpose = "Semantic structure, responsive layouts, and polished visual styling.",
          codeSample = """
            <main class="portfolio-shell" role="main">
              <section aria-labelledby="hero-title" class="hero-grid">
                <h1 id="hero-title">Engineering Digital Elegance</h1>
                <div class="glass-surface backdrop-blur-xl">...</div>
              </section>
            </main>
          """.trimIndent(),
          metrics = "Lighthouse 100/100 Accessibility & SEO",
          tag = "Semantic Web",
          keyFeatures = listOf(
            "ARIA-compliant landmark navigation",
            "CSS subgrid & container queries",
            "Hardware-accelerated transforms"
          )
        ),
        StackItem(
          technology = "Tailwind CSS",
          purpose = "Fast, consistent, responsive UI development and design-system styling.",
          codeSample = """
            <div className="group relative rounded-2xl bg-slate-900/60 p-8 
                            border border-cyan-500/20 backdrop-blur-xl 
                            hover:border-cyan-400/50 hover:shadow-[0_0_30px_rgba(56,189,248,0.2)] 
                            transition-all duration-500 ease-out">
              <span className="font-mono text-xs text-cyan-400">01 / IMMERSIVE</span>
            </div>
          """.trimIndent(),
          metrics = "Sub-12kB production CSS bundle via JIT",
          tag = "Design Tokens",
          keyFeatures = listOf(
            "JIT compiler utility architecture",
            "Bespoke tokenized dark-mode palette",
            "Dynamic clamp() fluid typography"
          )
        )
      )
    ),
    StackCategory(
      id = "motion",
      title = "Motion & Interaction",
      subtitle = "Cinematic storytelling & haptic feedback",
      iconName = "Motion",
      items = listOf(
        StackItem(
          technology = "GSAP",
          purpose = "Smooth, cinematic scroll animations, transitions, and interactive motion.",
          codeSample = """
            gsap.timeline({ scrollTrigger: { trigger: '#showcase', scrub: 1 } })
              .to('.hero-3d-model', { rotateY: 360, ease: 'power3.out' })
              .to('.depth-layer-front', { y: -120, opacity: 1 }, 0);
          """.trimIndent(),
          metrics = "Locked 60fps raf loop • Zero jank animations",
          tag = "Animation Engine",
          keyFeatures = listOf(
            "Hardware GPU matrix3d acceleration",
            "Timeline orchestration with Scrubbing",
            "Morphing SVG vectors & split text"
          )
        ),
        StackItem(
          technology = "Scroll-driven animation",
          purpose = "Interactive storytelling that responds naturally to user scrolling.",
          codeSample = """
            @supports (animation-timeline: scroll()) {
              .progress-glow {
                animation: scaleWidth auto linear;
                animation-timeline: scroll(root);
              }
            }
          """.trimIndent(),
          metrics = "Off-main-thread browser compositor execution",
          tag = "Scroll Engine",
          keyFeatures = listOf(
            "Native CSS scroll-driven timelines",
            "In-viewport intersection observers",
            "Velocity-aware parallax layering"
          )
        ),
        StackItem(
          technology = "Micro-interactions",
          purpose = "Subtle motion details that make the interface feel refined and responsive.",
          codeSample = """
            // Magnetic cursor spring physics
            const onPointerMove = (e: MouseEvent) => {
              const rect = el.getBoundingClientRect();
              const x = (e.clientX - rect.left - rect.width / 2) * 0.3;
              const y = (e.clientY - rect.top - rect.height / 2) * 0.3;
              spring.start({ x, y, tension: 300, friction: 20 });
            };
          """.trimIndent(),
          metrics = "<16ms input-to-render response threshold",
          tag = "Tactile UX",
          keyFeatures = listOf(
            "Magnetic button hover physics",
            "Elastic spring state transitions",
            "Particle trails & subtle glow ripples"
          )
        )
      )
    ),
    StackCategory(
      id = "immersive3d",
      title = "3D & Immersive Design",
      subtitle = "Dimensional visual experiences",
      iconName = "ViewInAr",
      items = listOf(
        StackItem(
          technology = "3D visual design",
          purpose = "Large-scale immersive hero visuals designed to create an immediate premium impression.",
          codeSample = """
            // PBR Material & Shading Configuration
            const glassMaterial = new MeshPhysicalMaterial({
              roughness: 0.1,
              transmission: 0.95,
              ior: 1.5,
              thickness: 1.2,
              iridescence: 0.8
            });
          """.trimIndent(),
          metrics = "Sub-100 draw calls • WebGL 2.0 / WebGPU ready",
          tag = "3D Graphics",
          keyFeatures = listOf(
            "Physically Based Rendering (PBR)",
            "Dynamic HDR environment reflections",
            "Procedural geometric tessellation"
          )
        ),
        StackItem(
          technology = "360° interactive presentation",
          purpose = "A complete rotational visual experience integrated into the hero section.",
          codeSample = """
            // Interactive 360 Orbit & Gyroscope Sync
            const updateTurntable = (deltaYaw: number, deltaPitch: number) => {
              model.rotation.y += deltaYaw * 0.02;
              model.rotation.x = Math.max(-0.6, Math.min(0.6, model.rotation.x + deltaPitch * 0.02));
            };
          """.trimIndent(),
          metrics = "Full 360-degree free inspection arc",
          tag = "Turntable UX",
          keyFeatures = listOf(
            "Smooth momentum & dampening drag",
            "Auto-cinematic spin idle mode",
            "Cross-axis perspective constraint"
          )
        ),
        StackItem(
          technology = "Depth & perspective",
          purpose = "Layered composition and perspective-based motion for a more dimensional interface.",
          codeSample = """
            // Multi-tier Z-index Parallax Depth
            const zLayers = [
              { element: '#bg-grid', depth: 0.05 },
              { element: '#artifact-core', depth: 0.25 },
              { element: '#floating-labels', depth: 0.65 }
            ];
          """.trimIndent(),
          metrics = "Multi-plane z-depth spatial hierarchy",
          tag = "Spatial UI",
          keyFeatures = listOf(
            "Layered parallax camera frustum",
            "Perspective field-of-view scaling",
            "Dynamic blur depth-of-field simulation"
          )
        )
      )
    ),
    StackCategory(
      id = "design",
      title = "UI / UX Design",
      subtitle = "Systematic precision & visual hierarchy",
      iconName = "Palette",
      items = listOf(
        StackItem(
          technology = "Figma",
          purpose = "Interface planning, visual systems, layouts, prototypes, and responsive design.",
          codeSample = """
            // Figma Design Token Export
            export const tokens = {
              colors: { obsidian: '#0A0E17', electricCyan: '#38BDF8', deepViolet: '#818CF8' },
              grid: { base: 8, gutter: 24, maxContainer: 1440 },
              radius: { sm: 6, md: 12, lg: 20, full: 9999 }
            };
          """.trimIndent(),
          metrics = "Auto-layout v5 components • Variable modes",
          tag = "Design System",
          keyFeatures = listOf(
            "Component token synchronization",
            "Responsive breakout variant frames",
            "Interactive high-fidelity prototypes"
          )
        ),
        StackItem(
          technology = "Design systems",
          purpose = "Consistent typography, spacing, components, and visual hierarchy.",
          codeSample = """
            // 8-Point Spatial System Scale
            const space = { 1: '4px', 2: '8px', 3: '12px', 4: '16px', 6: '24px', 8: '32px', 12: '48px' };
            const typeScale = { display: '3.75rem', h1: '2.5rem', body: '1.0rem', code: '0.875rem' };
          """.trimIndent(),
          metrics = "Strict 8-Point Grid alignment across all views",
          tag = "Hierarchy",
          keyFeatures = listOf(
            "Mathematical modular typography scale",
            "WCAG AAA contrast compliance ratios",
            "Reusable atomic card & button patterns"
          )
        ),
        StackItem(
          technology = "Responsive UX",
          purpose = "Layouts and interactions optimized across desktop, tablet, and mobile.",
          codeSample = """
            @media (min-width: 1024px) {
              .portfolio-layout { grid-template-columns: 320px 1fr 280px; }
            }
            @media (max-width: 768px) {
              .portfolio-layout { grid-template-columns: 1fr; }
            }
          """.trimIndent(),
          metrics = "Adaptive from 320px foldables to 4K ultrawides",
          tag = "Multi-Device",
          keyFeatures = listOf(
            "Touch-first ergonomic tap boundaries (48dp+)",
            "Dynamic split-pane supporting layouts",
            "Fluid viewport-based clamp sizing"
          )
        )
      )
    ),
    StackCategory(
      id = "delivery",
      title = "Performance & Delivery",
      subtitle = "Sub-second delivery & rock-solid architecture",
      iconName = "Speed",
      items = listOf(
        StackItem(
          technology = "Modern responsive architecture",
          purpose = "Built for fast rendering and smooth interaction across screen sizes.",
          codeSample = """
            // Next-gen SSR & Streaming Pipeline
            export default async function PortfolioPage() {
              return (
                <Suspense fallback={<HeroSkeleton />}>
                  <AsyncStreamedShowcase />
                </Suspense>
              );
            }
          """.trimIndent(),
          metrics = "LCP < 0.8s • CLS 0.00 • INP < 50ms",
          tag = "Performance",
          keyFeatures = listOf(
            "Partial Prerendering (PPR)",
            "Zero JavaScript for static content zones",
            "Edge CDN geo-distributed caching"
          )
        ),
        StackItem(
          technology = "Asset optimization",
          purpose = "Visual assets prepared with performance and loading experience in mind.",
          codeSample = """
            // Next-Gen Multi-Format Picture Tag
            <picture>
              <source srcset="/hero.avif" type="image/avif" />
              <source srcset="/hero.webp" type="image/webp" />
              <img src="/hero.jpg" loading="eager" fetchpriority="high" decoding="async" />
            </picture>
          """.trimIndent(),
          metrics = "92% asset compression vs raw PNG/JPEG",
          tag = "Optimization",
          keyFeatures = listOf(
            "AVIF & WebP automatic transcoding",
            "Progressive mesh LOD for 3D assets",
            "Sub-resource integrity (SRI) caching"
          )
        ),
        StackItem(
          technology = "Production-ready workflow",
          purpose = "Structured development approach for maintainable portfolio projects.",
          codeSample = """
            name: CI/CD Pipeline
            on: [push]
            jobs:
              audit:
                runs-on: ubuntu-latest
                steps:
                  - run: pnpm lint && pnpm typecheck && pnpm test
                  - run: pnpm lighthouserc --assert
          """.trimIndent(),
          metrics = "Automated CI/CD with Lighthouse performance budgets",
          tag = "DevOps",
          keyFeatures = listOf(
            "Automated bundle size budget gates",
            "Continuous deployment to global edge",
            "Dead-code tree shaking verification"
          )
        )
      )
    )
  )

  val sampleProjects = listOf(
    ProjectDemo(
      name = "Kinetic 3D Showroom",
      category = "3D & Motion",
      summary = "Interactive WebGL showcase featuring 360 turntable, physically based glass refractions, and GSAP scroll choreography.",
      techBadges = listOf("React", "Three.js", "GSAP", "Tailwind"),
      metrics = "60 FPS • 420kB bundle"
    ),
    ProjectDemo(
      name = "Aero Design System",
      category = "UI/UX & Architecture",
      summary = "Multi-brand tokenized design system with accessible components, dynamic theme switching, and automated Figma sync.",
      techBadges = listOf("TypeScript", "Tailwind", "Figma Tokens", "Storybook"),
      metrics = "100% WCAG AAA • 40+ Components"
    ),
    ProjectDemo(
      name = "Pulse Edge Portal",
      category = "Performance & Delivery",
      summary = "Ultra-fast developer documentation and live interactive code playground with sub-800ms global LCP.",
      techBadges = listOf("React 19", "Edge CDN", "TypeScript", "Tailwind"),
      metrics = "LCP 0.68s • 100/100 Core Web Vitals"
    )
  )
}

data class ProjectDemo(
  val name: String,
  val category: String,
  val summary: String,
  val techBadges: List<String>,
  val metrics: String
)
