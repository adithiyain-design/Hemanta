package com.example.model

data class ExperienceItem(
  val role: String,
  val company: String,
  val location: String,
  val duration: String,
  val periodYears: String,
  val highlights: List<String>,
  val tags: List<String>,
  val metrics: String
)

data class EducationItem(
  val institution: String,
  val universityOrBoard: String,
  val degree: String,
  val scoreOrCgpa: String,
  val year: String,
  val location: String
)

data class CertificationItem(
  val title: String,
  val code: String,
  val description: String,
  val institution: String,
  val iconName: String
)

data class SkillCategoryItem(
  val categoryName: String,
  val skills: List<SkillDetail>
)

data class SkillDetail(
  val name: String,
  val proficiency: Int, // 0 - 100
  val tag: String,
  val detail: String
)

object HemantaResumeData {
  const val FULL_NAME = "HEMANTA DUTTA"
  const val PROFESSIONAL_TITLE = "Accountant & Tax Consultant | Sales Specialist"
  const val LOCATION_SHORT = "Jorhat, Assam, India"
  const val FULL_ADDRESS = "House No. 11, Krishana Guru Sewashram, Old Kumar Kaybarta Gaon, Jorhat, Assam - 785007"
  const val PHONE_NUMBER = "9365678816"
  const val EMAIL_ADDRESS = "hdutta540@gmail.com"

  const val OBJECTIVE =
    "Dedicated and detail-oriented professional with 3 years of experience in accounting, tax consulting, and sales operations. Adept at utilizing financial software such as Tally and Ezy Rakod. Seeking to leverage my technical skills and accounting expertise to contribute effectively to a dynamic organization."

  const val DECLARATION_STATEMENT =
    "I hereby declared that the above information given by me is true to best of my Knowledge."

  val keyMetrics = listOf(
    "3+ Years" to "Accounting & Tax",
    "B.Com (Hons)" to "Dibrugarh Univ (6.69)",
    "3 Diplomas" to "PGDCA & Hardware",
    "100%" to "GST Accuracy"
  )

  val experiences = listOf(
    ExperienceItem(
      role = "Accountant",
      company = "Tax Consultant Firm",
      location = "Jorhat, Assam",
      duration = "Duration: 3 Years",
      periodYears = "3 Years (Full Time)",
      highlights = listOf(
        "Managed and recorded daily financial transactions, ensuring accurate accounting practices.",
        "Operated Tally software and Ezy Rakod for comprehensive bookkeeping and taxation data entry.",
        "Assisted in the preparation and filing of Goods and Services Tax (GST) returns.",
        "Maintained ledgers, reconciled bank statements, and generated financial reports for clients."
      ),
      tags = listOf("Tally ERP/Prime", "Ezy Rakod", "GST Filing", "Bank Reconciliation", "Ledger Audit"),
      metrics = "Over 100+ client accounts reconciled & zero GST penalty filings"
    ),
    ExperienceItem(
      role = "Sales Representative",
      company = "Nestle Distributor",
      location = "Jorhat, Assam",
      duration = "Duration: 1 Year",
      periodYears = "1 Year (Full Time)",
      highlights = listOf(
        "Facilitated the distribution and sales of Nestle products within the designated territory.",
        "Developed and maintained relationships with local retailers to optimize product placement and volume.",
        "Tracked inventory levels and ensured timely delivery of consumer goods."
      ),
      tags = listOf("FMCG Distribution", "Retailer Relations", "Inventory Tracking", "Territory Sales"),
      metrics = "Expanded retail coverage & consistent inventory replenishment"
    )
  )

  val educations = listOf(
    EducationItem(
      institution = "C.K.B. College, Teok",
      universityOrBoard = "Dibrugarh University",
      degree = "Bachelor of Commerce (B.Com) Honors",
      scoreOrCgpa = "CGPA: 6.69",
      year = "Graduated: 2023",
      location = "Jorhat, Assam"
    ),
    EducationItem(
      institution = "AHSEC Board",
      universityOrBoard = "Assam Higher Secondary Education Council",
      degree = "12th Standard (Higher Secondary)",
      scoreOrCgpa = "39.8%",
      year = "Year: 2020",
      location = "Assam"
    ),
    EducationItem(
      institution = "SEBA Board",
      universityOrBoard = "Secondary Education Board of Assam",
      degree = "10th Standard (High School)",
      scoreOrCgpa = "42.0%",
      year = "Year: 2018",
      location = "Assam"
    )
  )

  val certifications = listOf(
    CertificationItem(
      title = "Post Graduate Diploma in Computer Application",
      code = "PGDCA",
      description = "Advanced enterprise database operations, office automation suites, programming fundamentals, and system utilities.",
      institution = "Recognized Technical Institute",
      iconName = "Computer"
    ),
    CertificationItem(
      title = "Diploma in Computer Hardware Repairing & Desktop Publishing",
      code = "Hardware & DTP",
      description = "PC assembly, peripheral diagnostics, system troubleshooting, print design, PageMaker, Photoshop & typographical layouts.",
      institution = "Technical Training Board",
      iconName = "Build"
    ),
    CertificationItem(
      title = "Diploma in Computer Application",
      code = "Computer Application",
      description = "Core operating system mechanics, spreadsheet modeling, business documentation, and Internet communications.",
      institution = "Computer Education Center",
      iconName = "Terminal"
    )
  )

  val skillCategories = listOf(
    SkillCategoryItem(
      categoryName = "Software & Accounting Tools",
      skills = listOf(
        SkillDetail("Tally ERP 9 / TallyPrime", 95, "Accounting", "Daily vouchers, ledger posting, trial balance, GST invoices & stock registers"),
        SkillDetail("Ezy Rakod", 92, "Tax Software", "Specialized tax computation, client database management & bookkeeping entries"),
        SkillDetail("MS Excel", 90, "Spreadsheets", "VLOOKUP, Pivot Tables, SUMIFS, financial data sorting & reconciliation sheets"),
        SkillDetail("MS Word", 88, "Documentation", "Formal audit reports, client representation letters & business summaries"),
        SkillDetail("MS PowerPoint", 82, "Presentations", "Business proposals, distribution sales decks & quarterly review summaries")
      )
    ),
    SkillCategoryItem(
      categoryName = "Core Competencies & Operations",
      skills = listOf(
        SkillDetail("GST Filing (GSTR-1 & 3B)", 94, "Taxation", "Input Tax Credit (ITC) reconciliation, invoice matching, return preparation"),
        SkillDetail("Bank & Ledger Reconciliation", 92, "Audit", "Resolving discrepancies between passbooks and company ledgers with zero error"),
        SkillDetail("Sales & FMCG Distribution", 86, "Supply Chain", "Retailer relations, territory route planning, inventory tracking & logistics"),
        SkillDetail("Computer Hardware Repairing", 88, "Technical", "Component diagnostics, OS reinstallation, hardware upgrades & networking"),
        SkillDetail("Desktop Publishing (DTP)", 85, "Publishing", "Brochure typesetting, forms creation, regional language typing & layout")
      )
    ),
    SkillCategoryItem(
      categoryName = "Languages Spoken & Written",
      skills = listOf(
        SkillDetail("Assamese", 100, "Native", "Fluent spoken & written communication, local business rapport"),
        SkillDetail("Hindi", 90, "Professional", "Fluent verbal and trade correspondence"),
        SkillDetail("English", 82, "Professional", "Professional documentation, software interfaces, financial reports")
      )
    )
  )

  val interactiveGstSlabs = listOf(
    0.0 to "0% (Exempt Goods)",
    5.0 to "5% (Essential Goods/Services)",
    12.0 to "12% (Standard Category I)",
    18.0 to "18% (Standard Category II - Consulting & Services)",
    28.0 to "28% (Luxury & Consumer Electronics)"
  )
}
