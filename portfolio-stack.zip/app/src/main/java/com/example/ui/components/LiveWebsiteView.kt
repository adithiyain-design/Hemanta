package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tablet
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PortfolioData
import com.example.ui.theme.TechAmberAccent
import com.example.ui.theme.TechCyanLight
import com.example.ui.theme.TechCyanPrimary
import com.example.ui.theme.TechDarkSurfaceCard
import com.example.ui.theme.TechEmeraldAccent
import com.example.ui.theme.TechPinkTertiary
import com.example.ui.theme.TechVioletSecondary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LiveWebsiteView(
  modifier: Modifier = Modifier,
  onNavigateToStack: () -> Unit = {},
  onNavigateToAi: () -> Unit = {}
) {
  var selectedViewport by remember { mutableStateOf(DeviceViewport.DESKTOP) }
  var expandedProjectIndex by remember { mutableStateOf<Int?>(null) }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(Color(0xFF070A11))
      .verticalScroll(rememberScrollState())
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Top Browser Chrome Frame Header
    Card(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
      border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B))
    ) {
      Column(modifier = Modifier.padding(12.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          // Window traffic lights
          Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(Color(0xFFEF4444)))
            Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(Color(0xFFF59E0B)))
            Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(Color(0xFF10B981)))
          }

          // URL bar
          Surface(
            shape = RoundedCornerShape(20.dp),
            color = Color(0xFF0A0E17),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
            modifier = Modifier.weight(1f).padding(horizontal = 12.dp)
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                imageVector = Icons.Default.Public,
                contentDescription = null,
                tint = TechCyanLight,
                modifier = Modifier.size(14.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "https://portfolio.dev/showcase",
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                color = Color(0xFFCBD5E1)
              )
            }
          }

          // Responsive Viewport Switcher in Header
          Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            DeviceViewport.values().forEach { vp ->
              Box(
                modifier = Modifier
                  .size(28.dp)
                  .clip(RoundedCornerShape(6.dp))
                  .background(if (selectedViewport == vp) TechCyanPrimary.copy(0.25f) else Color.Transparent)
                  .border(1.dp, if (selectedViewport == vp) TechCyanPrimary else Color.Transparent, RoundedCornerShape(6.dp))
                  .clickable { selectedViewport = vp },
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  imageVector = when (vp) {
                    DeviceViewport.DESKTOP -> Icons.Default.Computer
                    DeviceViewport.TABLET -> Icons.Default.Tablet
                    DeviceViewport.MOBILE -> Icons.Default.PhoneAndroid
                  },
                  contentDescription = vp.label,
                  tint = if (selectedViewport == vp) TechCyanLight else Color(0xFF64748B),
                  modifier = Modifier.size(14.dp)
                )
              }
            }
          }
        }
      }
    }

    // Website Hero Section inside responsive shell
    Card(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(20.dp),
      colors = CardDefaults.cardColors(containerColor = TechDarkSurfaceCard),
      border = androidx.compose.foundation.BorderStroke(
        1.dp,
        Brush.horizontalGradient(listOf(TechCyanPrimary.copy(0.3f), TechVioletSecondary.copy(0.3f)))
      )
    ) {
      Column(modifier = Modifier.padding(18.dp)) {
        // Nav Pill
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(28.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(TechCyanPrimary),
              contentAlignment = Alignment.Center
            ) {
              Text("PS", fontWeight = FontWeight.Black, fontSize = 12.sp, color = Color(0xFF002A3D))
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text("PORTFOLIO.DEV", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.White)
          }

          Surface(
            shape = RoundedCornerShape(12.dp),
            color = Color(0xFF0F172A),
            border = androidx.compose.foundation.BorderStroke(1.dp, TechEmeraldAccent.copy(0.4f))
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(TechEmeraldAccent))
              Spacer(modifier = Modifier.width(6.dp))
              Text("OPEN TO ARCHITECTURE ROLES", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = TechEmeraldAccent)
            }
          }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Hero Headline
        Text(
          text = "Premium Portfolio — Tech & Design Stack",
          fontSize = 22.sp,
          fontWeight = FontWeight.Black,
          color = Color.White,
          lineHeight = 28.sp
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
          text = PortfolioData.STACK_INTRO,
          fontSize = 13.sp,
          color = Color(0xFF94A3B8),
          lineHeight = 18.sp
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Positioning Quote Box
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF0A0E17))
            .border(1.dp, TechCyanPrimary.copy(alpha = 0.25f), RoundedCornerShape(12.dp))
            .padding(12.dp)
        ) {
          Column {
            Text(
              text = "POSITIONING STATEMENT",
              fontFamily = FontFamily.Monospace,
              fontSize = 9.sp,
              fontWeight = FontWeight.Bold,
              color = TechCyanLight
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = PortfolioData.POSITIONING_STATEMENT,
              fontSize = 12.sp,
              color = Color(0xFFE2E8F0),
              lineHeight = 16.sp
            )
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Live 360 Turntable Hero Widget
        Interactive3DHeroSection(
          title = "Hero 3D Rotational Visual",
          subtitle = "360° interactive presentation & depth layers"
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Quick Action Buttons
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Button(
            onClick = onNavigateToStack,
            modifier = Modifier.weight(1f),
            colors = ButtonDefaults.buttonColors(containerColor = TechCyanPrimary),
            shape = RoundedCornerShape(12.dp)
          ) {
            Icon(Icons.Default.Code, contentDescription = null, tint = Color(0xFF002A3D))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Explore Tech Stack", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF002A3D))
          }

          Button(
            onClick = onNavigateToAi,
            modifier = Modifier.weight(1f),
            colors = ButtonDefaults.buttonColors(containerColor = TechVioletSecondary),
            shape = RoundedCornerShape(12.dp)
          ) {
            Icon(Icons.Default.RocketLaunch, contentDescription = null, tint = Color.White)
            Spacer(modifier = Modifier.width(6.dp))
            Text("AI Stack Audit", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
          }
        }
      }
    }

    // Featured Work Projects Section
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "Featured Production Projects",
          fontSize = 15.sp,
          fontWeight = FontWeight.Bold,
          color = Color.White
        )
        Text(
          text = "${PortfolioData.sampleProjects.size} Case Studies",
          fontFamily = FontFamily.Monospace,
          fontSize = 11.sp,
          color = Color(0xFF64748B)
        )
      }

      PortfolioData.sampleProjects.forEachIndexed { index, project ->
        val isExpanded = expandedProjectIndex == index
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .clickable {
              expandedProjectIndex = if (isExpanded) null else index
            }
            .testTag("project_card_$index"),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = TechDarkSurfaceCard),
          border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isExpanded) TechCyanPrimary else Color(0xFF1E293B)
          )
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text(
                  text = project.name,
                  fontSize = 15.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color.White
                )
                Text(
                  text = project.category,
                  fontSize = 11.sp,
                  color = TechCyanLight
                )
              }

              Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color(0xFF0F172A),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B))
              ) {
                Text(
                  text = project.metrics,
                  fontFamily = FontFamily.Monospace,
                  fontSize = 10.sp,
                  color = TechEmeraldAccent,
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
              }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
              text = project.summary,
              fontSize = 12.sp,
              color = Color(0xFF94A3B8),
              lineHeight = 16.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Tech Badges
            FlowRow(
              horizontalArrangement = Arrangement.spacedBy(6.dp),
              verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              project.techBadges.forEach { badge ->
                Surface(
                  shape = RoundedCornerShape(6.dp),
                  color = Color(0xFF0F172A),
                  border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334155))
                ) {
                  Text(
                    text = badge,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    color = Color(0xFFCBD5E1),
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                  )
                }
              }
            }

            AnimatedVisibility(visible = isExpanded) {
              Column(
                modifier = Modifier
                  .padding(top = 12.dp)
                  .clip(RoundedCornerShape(8.dp))
                  .background(Color(0xFF0A0E17))
                  .padding(10.dp)
              ) {
                Text(
                  text = "ARCHITECTURE HIGHLIGHTS",
                  fontFamily = FontFamily.Monospace,
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  color = TechVioletSecondary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                  text = "• Offloads 3D vertex processing to WebGL shaders\n• Full 60fps GSAP scrub orchestration\n• Zero runtime CSS overhead with Tailwind JIT",
                  fontSize = 11.sp,
                  color = Color(0xFFCBD5E1),
                  lineHeight = 15.sp
                )
              }
            }
          }
        }
      }
    }

    // Interactive Terminal Footer
    Card(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = Color(0xFF0B0F19)),
      border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B))
    ) {
      Column(modifier = Modifier.padding(14.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.Terminal,
              contentDescription = null,
              tint = TechEmeraldAccent,
              modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "TERMINAL INSPECTION",
              fontFamily = FontFamily.Monospace,
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
              color = Color.White
            )
          }

          Text(
            text = "zsh • node v22",
            fontFamily = FontFamily.Monospace,
            fontSize = 9.sp,
            color = Color(0xFF64748B)
          )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
          text = "$ portfolio inspect --stack\n✔ React 19 + TypeScript (Strict)\n✔ GSAP 3.12 + ScrollTrigger\n✔ WebGL 360° Turntable + PBR Shaders\n✔ Tailwind CSS JIT (<12kB)\n✔ Core Web Vitals: 100/100 LCP 0.72s",
          fontFamily = FontFamily.Monospace,
          fontSize = 11.sp,
          color = TechEmeraldAccent,
          lineHeight = 16.sp
        )
      }
    }

    Spacer(modifier = Modifier.height(16.dp))
  }
}
