package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.material.icons.filled.Waves
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PortfolioData
import com.example.model.StackCategory
import com.example.model.StackItem
import com.example.ui.theme.TechCyanLight
import com.example.ui.theme.TechCyanPrimary
import com.example.ui.theme.TechDarkSurfaceCard
import com.example.ui.theme.TechEmeraldAccent
import com.example.ui.theme.TechPinkTertiary
import com.example.ui.theme.TechVioletSecondary

@Composable
fun StackExplorerView(modifier: Modifier = Modifier) {
  var selectedCategoryId by remember { mutableStateOf<String?>("all") }
  var expandedItems by remember { mutableStateOf(setOf<String>()) }

  val categories = PortfolioData.categories
  val displayedCategories = if (selectedCategoryId == "all" || selectedCategoryId == null) {
    categories
  } else {
    categories.filter { it.id == selectedCategoryId }
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .padding(16.dp)
      .verticalScroll(rememberScrollState()),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Header
    Column {
      Text(
        text = "Tech & Design Stack",
        fontSize = 20.sp,
        fontWeight = FontWeight.Black,
        color = Color.White
      )
      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = "Complete technologies, purposes, and code architectures",
        fontSize = 12.sp,
        color = Color(0xFF94A3B8)
      )
    }

    // Category Filter Chips Row
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .horizontalScroll(rememberScrollState()),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      FilterPill(
        title = "All Stack (${categories.flatMap { it.items }.size})",
        isSelected = selectedCategoryId == "all",
        onClick = { selectedCategoryId = "all" }
      )
      categories.forEach { cat ->
        FilterPill(
          title = cat.title,
          isSelected = selectedCategoryId == cat.id,
          onClick = { selectedCategoryId = cat.id }
        )
      }
    }

    // Categories and their items
    displayedCategories.forEach { category ->
      CategorySection(
        category = category,
        expandedItems = expandedItems,
        onToggleItem = { techName ->
          expandedItems = if (expandedItems.contains(techName)) {
            expandedItems - techName
          } else {
            expandedItems + techName
          }
        }
      )
    }

    Spacer(modifier = Modifier.height(16.dp))
  }
}

@Composable
private fun FilterPill(
  title: String,
  isSelected: Boolean,
  onClick: () -> Unit
) {
  Box(
    modifier = Modifier
      .clip(RoundedCornerShape(20.dp))
      .background(if (isSelected) TechCyanPrimary else Color(0xFF111827))
      .border(
        1.dp,
        if (isSelected) TechCyanPrimary else Color(0xFF1E293B),
        RoundedCornerShape(20.dp)
      )
      .clickable { onClick() }
      .padding(horizontal = 12.dp, vertical = 6.dp)
  ) {
    Text(
      text = title,
      fontSize = 11.sp,
      fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
      color = if (isSelected) Color(0xFF002A3D) else Color(0xFFCBD5E1)
    )
  }
}

@Composable
private fun CategorySection(
  category: StackCategory,
  expandedItems: Set<String>,
  onToggleItem: (String) -> Unit
) {
  Column(
    modifier = Modifier.fillMaxWidth(),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    // Section Header
    Row(
      verticalAlignment = Alignment.CenterVertically,
      modifier = Modifier.padding(vertical = 4.dp)
    ) {
      Box(
        modifier = Modifier
          .size(28.dp)
          .clip(CircleShape)
          .background(
            when (category.id) {
              "frontend" -> TechCyanPrimary.copy(0.2f)
              "motion" -> TechVioletSecondary.copy(0.2f)
              "immersive3d" -> TechPinkTertiary.copy(0.2f)
              "design" -> TechEmeraldAccent.copy(0.2f)
              else -> TechCyanLight.copy(0.2f)
            }
          ),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = getCategoryIcon(category.iconName),
          contentDescription = null,
          tint = when (category.id) {
            "frontend" -> TechCyanLight
            "motion" -> TechVioletSecondary
            "immersive3d" -> TechPinkTertiary
            "design" -> TechEmeraldAccent
            else -> TechCyanLight
          },
          modifier = Modifier.size(16.dp)
        )
      }
      Spacer(modifier = Modifier.width(8.dp))
      Column {
        Text(
          text = category.title,
          fontSize = 15.sp,
          fontWeight = FontWeight.Bold,
          color = Color.White
        )
        Text(
          text = category.subtitle,
          fontSize = 10.sp,
          color = Color(0xFF64748B)
        )
      }
    }

    // Items list
    category.items.forEach { item ->
      val isExpanded = expandedItems.contains(item.technology)
      StackItemCard(
        item = item,
        isExpanded = isExpanded,
        onToggle = { onToggleItem(item.technology) }
      )
    }
  }
}

@Composable
private fun StackItemCard(
  item: StackItem,
  isExpanded: Boolean,
  onToggle: () -> Unit
) {
  val clipboardManager = LocalClipboardManager.current
  var copied by remember { mutableStateOf(false) }

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(14.dp))
      .clickable { onToggle() }
      .testTag("stack_item_${item.technology.replace(" ", "_").lowercase()}"),
    colors = CardDefaults.cardColors(containerColor = TechDarkSurfaceCard),
    border = androidx.compose.foundation.BorderStroke(
      1.dp,
      if (isExpanded) TechCyanPrimary.copy(alpha = 0.5f) else Color(0xFF1E293B)
    )
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      // Title and Tag
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = item.technology,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
          )
          Spacer(modifier = Modifier.width(8.dp))
          Surface(
            shape = RoundedCornerShape(6.dp),
            color = Color(0xFF0F172A),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334155))
          ) {
            Text(
              text = item.tag,
              fontFamily = FontFamily.Monospace,
              fontSize = 9.sp,
              color = TechCyanLight,
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
          }
        }

        Icon(
          imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
          contentDescription = null,
          tint = Color(0xFF94A3B8)
        )
      }

      Spacer(modifier = Modifier.height(6.dp))

      // Purpose from PDF
      Text(
        text = item.purpose,
        fontSize = 12.sp,
        color = Color(0xFFCBD5E1),
        lineHeight = 16.sp
      )

      Spacer(modifier = Modifier.height(6.dp))

      // Metrics indicator
      Row(verticalAlignment = Alignment.CenterVertically) {
        Box(modifier = Modifier.size(5.dp).clip(CircleShape).background(TechEmeraldAccent))
        Spacer(modifier = Modifier.width(5.dp))
        Text(
          text = item.metrics,
          fontFamily = FontFamily.Monospace,
          fontSize = 10.sp,
          color = TechEmeraldAccent
        )
      }

      // Expandable section with code and features
      AnimatedVisibility(visible = isExpanded) {
        Column(modifier = Modifier.padding(top = 12.dp)) {
          // Key features bullets
          Text(
            text = "KEY ARCHITECTURE CAPABILITIES",
            fontFamily = FontFamily.Monospace,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF64748B)
          )
          Spacer(modifier = Modifier.height(4.dp))
          item.keyFeatures.forEach { feat ->
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.padding(vertical = 2.dp)
            ) {
              Text("• ", color = TechCyanPrimary, fontSize = 11.sp)
              Text(feat, fontSize = 11.sp, color = Color(0xFF94A3B8))
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // Code Box
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "PRODUCTION IMPLEMENTATION",
              fontFamily = FontFamily.Monospace,
              fontSize = 9.sp,
              fontWeight = FontWeight.Bold,
              color = TechCyanLight
            )

            IconButton(
              onClick = {
                clipboardManager.setText(AnnotatedString(item.codeSample))
                copied = true
              },
              modifier = Modifier.size(24.dp)
            ) {
              Icon(
                imageVector = if (copied) Icons.Default.Check else Icons.Default.ContentCopy,
                contentDescription = "Copy code",
                tint = if (copied) TechEmeraldAccent else Color(0xFF94A3B8),
                modifier = Modifier.size(14.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(4.dp))

          Box(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(8.dp))
              .background(Color(0xFF070A11))
              .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(8.dp))
              .padding(10.dp)
          ) {
            Text(
              text = item.codeSample,
              fontFamily = FontFamily.Monospace,
              fontSize = 10.sp,
              color = Color(0xFF93C5FD),
              lineHeight = 14.sp
            )
          }
        }
      }
    }
  }
}

private fun getCategoryIcon(name: String): ImageVector {
  return when (name) {
    "Code" -> Icons.Default.Code
    "Motion" -> Icons.Default.Waves
    "ViewInAr" -> Icons.Default.ViewInAr
    "Palette" -> Icons.Default.Palette
    "Speed" -> Icons.Default.Speed
    else -> Icons.Default.Layers
  }
}
