package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Dark Luxury Portfolio Palette
val TechDarkBackground = Color(0xFF0A0E17)
val TechDarkSurface = Color(0xFF111827)
val TechDarkSurfaceVariant = Color(0xFF1E293B)
val TechDarkSurfaceCard = Color(0xFF162032)

val TechCyanPrimary = Color(0xFF38BDF8)
val TechCyanLight = Color(0xFF7DD3FC)
val TechCyanDark = Color(0xFF0284C7)

val TechVioletSecondary = Color(0xFF818CF8)
val TechVioletLight = Color(0xFFA5B4FC)
val TechPinkTertiary = Color(0xFFF472B6)

val TechEmeraldAccent = Color(0xFF34D399)
val TechAmberAccent = Color(0xFFFBBF24)

val TechBorderDark = Color(0xFF243248)
val TechBorderGlow = Color(0x3338BDF8)

val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFF94A3B8)
val TextMutedDark = Color(0xFF64748B)

// Light Theme Palette
val TechLightBackground = Color(0xFFF8FAFC)
val TechLightSurface = Color(0xFFFFFFFF)
val TechLightSurfaceVariant = Color(0xFFF1F5F9)
val TechLightPrimary = Color(0xFF0284C7)
val TechLightSecondary = Color(0xFF4F46E5)
val TechLightTertiary = Color(0xFFDB2777)
val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF475569)
