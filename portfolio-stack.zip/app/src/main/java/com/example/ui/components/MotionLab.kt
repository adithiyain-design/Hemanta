package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Waves
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.TechCyanLight
import com.example.ui.theme.TechCyanPrimary
import com.example.ui.theme.TechDarkSurfaceCard
import com.example.ui.theme.TechEmeraldAccent
import com.example.ui.theme.TechPinkTertiary
import com.example.ui.theme.TechVioletSecondary
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

@Composable
fun MotionLabSection(modifier: Modifier = Modifier) {
  var selectedTab by remember { mutableIntStateOf(0) }
  val tabTitles = listOf("GSAP Physics", "Scroll-Driven", "Micro-Interactions")

  Card(
    modifier = modifier.fillMaxWidth(),
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(containerColor = TechDarkSurfaceCard),
    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B))
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
          modifier = Modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(TechVioletSecondary.copy(alpha = 0.18f)),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.Waves,
            contentDescription = "Motion",
            tint = TechVioletSecondary,
            modifier = Modifier.size(20.dp)
          )
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column {
          Text(
            text = "Motion & Interaction Lab",
            style = MaterialTheme.typography.titleMedium.copy(
              fontWeight = FontWeight.Bold,
              color = Color.White
            )
          )
          Text(
            text = "GSAP physics, scroll-driven timelines & micro-motion",
            style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFF94A3B8))
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Tab switcher
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(12.dp))
          .background(Color(0xFF0F172A))
          .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
      ) {
        tabTitles.forEachIndexed { index, title ->
          val isSelected = selectedTab == index
          Box(
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(8.dp))
              .background(if (isSelected) TechVioletSecondary.copy(alpha = 0.25f) else Color.Transparent)
              .border(
                1.dp,
                if (isSelected) TechVioletSecondary.copy(alpha = 0.6f) else Color.Transparent,
                RoundedCornerShape(8.dp)
              )
              .clickable { selectedTab = index }
              .padding(vertical = 8.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = title,
              fontSize = 11.sp,
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
              color = if (isSelected) Color.White else Color(0xFF94A3B8)
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      when (selectedTab) {
        0 -> GsapPhysicsDemonstrator()
        1 -> ScrollDrivenTimelineDemonstrator()
        2 -> MicroInteractionsDemonstrator()
      }
    }
  }
}

@Composable
private fun GsapPhysicsDemonstrator() {
  val scope = rememberCoroutineScope()
  var stiffness by remember { mutableFloatStateOf(Spring.StiffnessMedium) }
  var dampingRatio by remember { mutableFloatStateOf(Spring.DampingRatioMediumBouncy) }
  val offsetAnim = remember { Animatable(0f) }
  var isAnimating by remember { mutableStateOf(false) }

  fun triggerGsapBounce() {
    scope.launch {
      isAnimating = true
      offsetAnim.snapTo(-140f)
      offsetAnim.animateTo(
        targetValue = 0f,
        animationSpec = spring(
          dampingRatio = dampingRatio,
          stiffness = stiffness
        )
      )
      isAnimating = false
    }
  }

  Column(modifier = Modifier.fillMaxWidth()) {
    // Visual viewport
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .height(160.dp)
        .clip(RoundedCornerShape(14.dp))
        .background(Color(0xFF090D16))
        .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(14.dp)),
      contentAlignment = Alignment.Center
    ) {
      // Background spring guidelines
      Canvas(modifier = Modifier.fillMaxSize()) {
        val midY = size.height / 2
        drawLine(
          color = Color(0x2238BDF8),
          start = Offset(40f, midY),
          end = Offset(size.width - 40f, midY),
          strokeWidth = 2f
        )
      }

      // Physics Target Element
      Box(
        modifier = Modifier
          .offset { IntOffset(x = offsetAnim.value.roundToInt() * 2, y = 0) }
          .size(68.dp)
          .clip(RoundedCornerShape(16.dp))
          .background(
            Brush.linearGradient(
              listOf(TechCyanPrimary, TechVioletSecondary)
            )
          )
          .border(1.5.dp, Color.White.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
          .clickable { triggerGsapBounce() },
        contentAlignment = Alignment.Center
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Icon(
            imageVector = Icons.Default.PlayArrow,
            contentDescription = "Trigger",
            tint = Color.White,
            modifier = Modifier.size(24.dp)
          )
          Text(
            text = "GSAP",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            color = Color.White
          )
        }
      }

      Text(
        text = "Tension: ${stiffness.toInt()}  |  Friction Damping: ${String.format("%.2f", dampingRatio)}",
        fontFamily = FontFamily.Monospace,
        fontSize = 10.sp,
        color = Color(0xFF64748B),
        modifier = Modifier
          .align(Alignment.BottomStart)
          .padding(8.dp)
      )
    }

    Spacer(modifier = Modifier.height(12.dp))

    // Damping preset pills
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = "Spring Easing Preset:",
        fontSize = 12.sp,
        color = Color(0xFF94A3B8)
      )

      Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        AssistChip(
          onClick = {
            dampingRatio = Spring.DampingRatioHighBouncy
            stiffness = Spring.StiffnessLow
            triggerGsapBounce()
          },
          label = { Text("Elastic") },
          colors = AssistChipDefaults.assistChipColors(
            labelColor = if (dampingRatio == Spring.DampingRatioHighBouncy) TechCyanLight else Color(0xFF94A3B8)
          )
        )
        AssistChip(
          onClick = {
            dampingRatio = Spring.DampingRatioMediumBouncy
            stiffness = Spring.StiffnessMedium
            triggerGsapBounce()
          },
          label = { Text("Expo") },
          colors = AssistChipDefaults.assistChipColors(
            labelColor = if (dampingRatio == Spring.DampingRatioMediumBouncy) TechCyanLight else Color(0xFF94A3B8)
          )
        )
        AssistChip(
          onClick = {
            dampingRatio = Spring.DampingRatioNoBouncy
            stiffness = Spring.StiffnessHigh
            triggerGsapBounce()
          },
          label = { Text("Snappy") },
          colors = AssistChipDefaults.assistChipColors(
            labelColor = if (dampingRatio == Spring.DampingRatioNoBouncy) TechCyanLight else Color(0xFF94A3B8)
          )
        )
      }
    }

    Spacer(modifier = Modifier.height(8.dp))

    Button(
      onClick = { triggerGsapBounce() },
      modifier = Modifier
        .fillMaxWidth()
        .testTag("trigger_gsap_bounce_btn"),
      colors = ButtonDefaults.buttonColors(containerColor = TechVioletSecondary)
    ) {
      Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null)
      Spacer(modifier = Modifier.width(6.dp))
      Text("Trigger GSAP Velocity Impulse")
    }
  }
}

@Composable
private fun ScrollDrivenTimelineDemonstrator() {
  var scrollProgress by remember { mutableFloatStateOf(0.45f) }

  // Derive parallax motion values from scroll progress
  val heroRotation = scrollProgress * 360f
  val heroScale = 0.8f + (scrollProgress * 0.4f)
  val layerYOffset = (scrollProgress - 0.5f) * 120f
  val textOpacity = (1f - (scrollProgress - 0.3f).let { if (it > 0) it * 1.5f else 0f }).coerceIn(0.1f, 1f)

  Column(modifier = Modifier.fillMaxWidth()) {
    // Parallax Stage Canvas
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .height(180.dp)
        .clip(RoundedCornerShape(14.dp))
        .background(Color(0xFF090D16))
        .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(14.dp)),
      contentAlignment = Alignment.Center
    ) {
      // Layer 1 (Deep background grid)
      Box(
        modifier = Modifier
          .fillMaxSize()
          .offset { IntOffset(0, (layerYOffset * 0.25f).roundToInt()) }
          .alpha(0.3f)
      ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
          val step = 24.dp.toPx()
          for (x in 0..(size.width / step).toInt()) {
            drawLine(Color(0xFF1E293B), Offset(x * step, 0f), Offset(x * step, size.height), 1f)
          }
        }
      }

      // Layer 2 (Headline text parallax)
      Column(
        modifier = Modifier
          .offset { IntOffset(0, (-layerYOffset * 0.8f).roundToInt()) }
          .alpha(textOpacity),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Text(
          text = "CINEMATIC SCROLL",
          fontSize = 18.sp,
          fontWeight = FontWeight.Black,
          letterSpacing = 2.sp,
          color = Color.White
        )
        Text(
          text = "Interactive storytelling responding to user scroll",
          fontSize = 11.sp,
          color = TechCyanLight
        )
      }

      // Layer 3 (Foreground 3D Card rotated by scroll scrub)
      Box(
        modifier = Modifier
          .offset { IntOffset(0, (layerYOffset * 0.5f).roundToInt()) }
          .size(72.dp)
          .rotate(heroRotation)
          .scale(heroScale)
          .clip(RoundedCornerShape(16.dp))
          .background(
            Brush.sweepGradient(
              listOf(TechCyanPrimary, TechVioletSecondary, TechPinkTertiary, TechCyanPrimary)
            )
          )
          .border(2.dp, Color.White.copy(alpha = 0.8f), RoundedCornerShape(16.dp)),
        contentAlignment = Alignment.Center
      ) {
        Box(
          modifier = Modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(Color(0xCC0F172A)),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = "${(scrollProgress * 100).toInt()}%",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 10.sp,
            color = TechCyanLight
          )
        }
      }

      // Progress bar indicator
      Box(
        modifier = Modifier
          .align(Alignment.BottomStart)
          .fillMaxWidth(scrollProgress)
          .height(3.dp)
          .background(TechCyanPrimary)
      )
    }

    Spacer(modifier = Modifier.height(12.dp))

    // Interactive Scroll Scrub Slider
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = "Scroll Scrub:",
        fontSize = 12.sp,
        color = Color(0xFF94A3B8),
        modifier = Modifier.width(85.dp)
      )
      Slider(
        value = scrollProgress,
        onValueChange = { scrollProgress = it },
        valueRange = 0f..1f,
        modifier = Modifier
          .weight(1f)
          .testTag("scroll_scrub_slider"),
        colors = SliderDefaults.colors(
          thumbColor = TechCyanPrimary,
          activeTrackColor = TechCyanPrimary,
          inactiveTrackColor = Color(0xFF1E293B)
        )
      )
      Text(
        text = "${(scrollProgress * 100).toInt()}%",
        fontFamily = FontFamily.Monospace,
        fontSize = 12.sp,
        color = TechCyanLight,
        modifier = Modifier
          .width(42.dp)
          .padding(start = 4.dp)
      )
    }
  }
}

@Composable
private fun MicroInteractionsDemonstrator() {
  var clickCount by remember { mutableIntStateOf(0) }
  var isPressed by remember { mutableStateOf(false) }
  val scale by animateFloatAsState(
    targetValue = if (isPressed) 0.92f else 1.0f,
    animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
    label = "btn_bounce"
  )

  var magneticOffset by remember { mutableStateOf(Offset.Zero) }

  Column(
    modifier = Modifier.fillMaxWidth(),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    Text(
      text = "Subtle tactile details engineered for responsive feedback:",
      fontSize = 12.sp,
      color = Color(0xFF94A3B8)
    )

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      // Interactive Tactile Button
      Box(
        modifier = Modifier
          .weight(1f)
          .height(100.dp)
          .clip(RoundedCornerShape(14.dp))
          .background(Color(0xFF0F172A))
          .border(1.dp, TechCyanPrimary.copy(alpha = 0.3f), RoundedCornerShape(14.dp))
          .scale(scale)
          .clickable {
            clickCount++
            isPressed = true
          }
          .padding(12.dp),
        contentAlignment = Alignment.Center
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Icon(
            imageVector = Icons.Default.TouchApp,
            contentDescription = null,
            tint = TechCyanLight,
            modifier = Modifier.size(24.dp)
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "Spring Ripple",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
          )
          Text(
            text = "Taps: $clickCount",
            fontFamily = FontFamily.Monospace,
            fontSize = 10.sp,
            color = TechCyanPrimary
          )
        }
      }

      // Magnetic Glow Target
      Box(
        modifier = Modifier
          .weight(1f)
          .height(100.dp)
          .clip(RoundedCornerShape(14.dp))
          .background(Color(0xFF0F172A))
          .border(1.dp, TechPinkTertiary.copy(alpha = 0.3f), RoundedCornerShape(14.dp))
          .clickable {
            clickCount++
          }
          .padding(12.dp),
        contentAlignment = Alignment.Center
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Icon(
            imageVector = Icons.Default.AutoAwesome,
            contentDescription = null,
            tint = TechPinkTertiary,
            modifier = Modifier.size(24.dp)
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "Neon Flare",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
          )
          Text(
            text = "<16ms latency",
            fontFamily = FontFamily.Monospace,
            fontSize = 10.sp,
            color = Color(0xFF94A3B8)
          )
        }
      }
    }
  }
}
