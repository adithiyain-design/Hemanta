package com.example.ui.components

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.ArrowOutward
import androidx.compose.material.icons.filled.AssignmentTurnedIn
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.HemantaResumeData
import com.example.ui.theme.LocalTheme3D
import com.example.ui.theme.Theme3DConfig
import com.example.ui.theme.Theme3DPresets

enum class ViewportMode(val title: String, val maxWidthDp: Int) {
  DESKTOP("Desktop (1440px)", 900),
  TABLET("Tablet (768px)", 680),
  MOBILE("Mobile (375px)", 420)
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun Resume3DWebsiteView(
  modifier: Modifier = Modifier,
  onThemeSelected: (Theme3DConfig) -> Unit
) {
  val theme3D = LocalTheme3D.current
  val context = LocalContext.current
  val clipboardManager = LocalClipboardManager.current

  var viewportMode by remember { mutableStateOf(ViewportMode.DESKTOP) }
  var showHireDialog by remember { mutableStateOf(false) }
  var showDeclarationDialog by remember { mutableStateOf(false) }
  var showThemeSelector by remember { mutableStateOf(false) }

  val scrollState = rememberScrollState()

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(theme3D.background)
  ) {
    // Top Browser Chrome Header
    BrowserChromeHeader(
      theme3D = theme3D,
      currentViewport = viewportMode,
      onViewportChange = { viewportMode = it },
      onOpenThemePicker = { showThemeSelector = true }
    )

    // 3D Themes Quick Picker Bar
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .background(theme3D.surface)
        .border(1.dp, theme3D.border)
        .padding(horizontal = 12.dp, vertical = 6.dp)
        .horizontalScroll(rememberScrollState()),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      Text(
        text = "3D THEMES:",
        fontFamily = FontFamily.Monospace,
        fontSize = 10.sp,
        fontWeight = FontWeight.Bold,
        color = theme3D.primaryLight
      )

      Theme3DPresets.ALL_THEMES.forEach { preset ->
        val isSelected = preset.id == theme3D.id
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) preset.primary.copy(alpha = 0.25f) else Color(0xFF0F172A))
            .border(
              1.dp,
              if (isSelected) preset.primary else theme3D.border,
              RoundedCornerShape(8.dp)
            )
            .clickable { onThemeSelected(preset) }
            .padding(horizontal = 10.dp, vertical = 4.dp)
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(preset.primary)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = preset.name,
              fontSize = 11.sp,
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
              color = if (isSelected) Color.White else theme3D.textSecondary
            )
          }
        }
      }
    }

    // Main Website Body with responsive width container
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .weight(1f),
      contentAlignment = Alignment.TopCenter
    ) {
      Column(
        modifier = Modifier
          .widthIn(max = viewportMode.maxWidthDp.dp)
          .fillMaxWidth()
          .verticalScroll(scrollState)
          .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
      ) {
        // Hero Section
        WebsiteHeroSection(
          theme3D = theme3D,
          onHireClick = { showHireDialog = true },
          onDeclarationClick = { showDeclarationDialog = true }
        )

        // 360° Interactive 3D Model Hero Viewer
        Interactive3DHeroSection(
          title = "Hemanta Dutta 3D Matrix",
          subtitle = "360° Spatial Projection • Rotate & Inspect Core Pillars"
        )

        // Key Career Metrics Bar
        KeyMetricsSection(theme3D = theme3D)

        // Work Experience Timeline
        WorkExperienceSection(theme3D = theme3D)

        // Live GST & Tax Calculator Sandbox
        GstTaxCalculator()

        // Software & Core Competencies Matrix
        SkillsAndSoftwareSection(theme3D = theme3D)

        // Education & Certifications
        EducationAndCertificationsSection(theme3D = theme3D)

        // Official Declaration & Location Card
        OfficialDeclarationCard(
          theme3D = theme3D,
          onViewFull = { showDeclarationDialog = true }
        )

        // Footer
        WebsiteFooter(theme3D = theme3D)
        Spacer(modifier = Modifier.height(30.dp))
      }
    }
  }

  // Hire & Contact Dialog
  if (showHireDialog) {
    AlertDialog(
      onDismissRequest = { showHireDialog = false },
      title = {
        Text("Contact & Hire Hemanta Dutta", fontWeight = FontWeight.Bold)
      },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Text(
            "Accountant & Tax Consultant with 3 years experience in Tally, Ezy Rakod, and GST filing in Jorhat, Assam.",
            fontSize = 13.sp,
            color = theme3D.textSecondary
          )
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(10.dp))
              .background(theme3D.surface)
              .padding(12.dp)
          ) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
              Text("Phone: ${HemantaResumeData.PHONE_NUMBER}", fontWeight = FontWeight.Bold, color = theme3D.primaryLight)
              Text("Email: ${HemantaResumeData.EMAIL_ADDRESS}", fontWeight = FontWeight.Bold, color = theme3D.primaryLight)
              Text("Location: ${HemantaResumeData.FULL_ADDRESS}", fontSize = 11.sp, color = theme3D.textMuted)
            }
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            val intent = Intent(Intent.ACTION_DIAL).apply {
              data = Uri.parse("tel:${HemantaResumeData.PHONE_NUMBER}")
            }
            context.startActivity(intent)
            showHireDialog = false
          },
          colors = ButtonDefaults.buttonColors(containerColor = theme3D.primary)
        ) {
          Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("Direct Call")
        }
      },
      dismissButton = {
        OutlinedButton(
          onClick = {
            val intent = Intent(Intent.ACTION_SENDTO).apply {
              data = Uri.parse("mailto:${HemantaResumeData.EMAIL_ADDRESS}")
              putExtra(Intent.EXTRA_SUBJECT, "Job Opportunity for Hemanta Dutta (Accountant / Tax)")
            }
            context.startActivity(intent)
            showHireDialog = false
          }
        ) {
          Icon(Icons.Default.Email, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("Send Email")
        }
      },
      containerColor = theme3D.surfaceCard,
      titleContentColor = Color.White,
      textContentColor = theme3D.textSecondary
    )
  }

  // Official Declaration Dialog
  if (showDeclarationDialog) {
    AlertDialog(
      onDismissRequest = { showDeclarationDialog = false },
      title = {
        Text("Official Resume Declaration", fontWeight = FontWeight.Bold)
      },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(10.dp))
              .background(theme3D.surface)
              .border(1.dp, theme3D.border, RoundedCornerShape(10.dp))
              .padding(14.dp)
          ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
              Text(
                "\"${HemantaResumeData.DECLARATION_STATEMENT}\"",
                fontSize = 13.sp,
                fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                color = Color.White
              )
              Spacer(modifier = Modifier.height(4.dp))
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Text("Place: JORHAT, ASSAM", fontSize = 11.sp, color = theme3D.textSecondary)
                Text("(HEMANTA DUTTA)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = theme3D.primaryLight)
              }
            }
          }
        }
      },
      confirmButton = {
        Button(
          onClick = { showDeclarationDialog = false },
          colors = ButtonDefaults.buttonColors(containerColor = theme3D.primary)
        ) {
          Text("Verified & Acknowledged")
        }
      },
      containerColor = theme3D.surfaceCard,
      titleContentColor = Color.White
    )
  }
}

@Composable
private fun BrowserChromeHeader(
  theme3D: Theme3DConfig,
  currentViewport: ViewportMode,
  onViewportChange: (ViewportMode) -> Unit,
  onOpenThemePicker: () -> Unit
) {
  Surface(
    color = theme3D.surfaceCard,
    border = androidx.compose.foundation.BorderStroke(1.dp, theme3D.border),
    modifier = Modifier.fillMaxWidth()
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 12.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      // Traffic Light Dots
      Row(
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(Color(0xFFFF5F56)))
        Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(Color(0xFFFFBD2E)))
        Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(Color(0xFF27C93F)))
      }

      // Live URL pill
      Box(
        modifier = Modifier
          .weight(1f)
          .padding(horizontal = 12.dp)
          .clip(RoundedCornerShape(20.dp))
          .background(theme3D.background)
          .border(1.dp, theme3D.border, RoundedCornerShape(20.dp))
          .padding(horizontal = 10.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Default.Language,
            contentDescription = "Secure URL",
            tint = theme3D.accent,
            modifier = Modifier.size(13.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "https://hemantadutta.dev",
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            color = theme3D.textSecondary
          )
        }
      }

      // Viewport mode selector
      Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        ViewportMode.values().forEach { mode ->
          val isSelected = currentViewport == mode
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(6.dp))
              .background(if (isSelected) theme3D.primary.copy(alpha = 0.2f) else Color.Transparent)
              .clickable { onViewportChange(mode) }
              .padding(horizontal = 6.dp, vertical = 4.dp)
          ) {
            Text(
              text = when (mode) {
                ViewportMode.DESKTOP -> "DESK"
                ViewportMode.TABLET -> "TAB"
                ViewportMode.MOBILE -> "MOB"
              },
              fontSize = 10.sp,
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
              color = if (isSelected) theme3D.primaryLight else theme3D.textMuted
            )
          }
        }
      }
    }
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun WebsiteHeroSection(
  theme3D: Theme3DConfig,
  onHireClick: () -> Unit,
  onDeclarationClick: () -> Unit
) {
  val context = LocalContext.current

  Column(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(22.dp))
      .background(
        Brush.verticalGradient(
          listOf(theme3D.surfaceCard, theme3D.surface)
        )
      )
      .border(1.dp, theme3D.border, RoundedCornerShape(22.dp))
      .padding(18.dp)
  ) {
    // Status Pill
    Row(
      modifier = Modifier
        .clip(RoundedCornerShape(30.dp))
        .background(theme3D.accent.copy(alpha = 0.15f))
        .border(1.dp, theme3D.accent.copy(alpha = 0.3f), RoundedCornerShape(30.dp))
        .padding(horizontal = 10.dp, vertical = 4.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(
        modifier = Modifier
          .size(7.dp)
          .clip(CircleShape)
          .background(theme3D.accent)
      )
      Spacer(modifier = Modifier.width(6.dp))
      Text(
        text = "OPEN FOR ACCOUNTING & TAX ROLES IN ASSAM / INDIA",
        fontFamily = FontFamily.Monospace,
        fontSize = 10.sp,
        fontWeight = FontWeight.Bold,
        color = theme3D.accent
      )
    }

    Spacer(modifier = Modifier.height(14.dp))

    // Profile Name & Title
    Text(
      text = HemantaResumeData.FULL_NAME,
      style = MaterialTheme.typography.headlineMedium.copy(
        fontWeight = FontWeight.Black,
        color = Color.White,
        letterSpacing = 1.sp
      )
    )

    Text(
      text = HemantaResumeData.PROFESSIONAL_TITLE,
      style = MaterialTheme.typography.titleMedium.copy(
        fontWeight = FontWeight.Bold,
        brush = theme3D.heroGradient
      )
    )

    Spacer(modifier = Modifier.height(8.dp))

    Row(verticalAlignment = Alignment.CenterVertically) {
      Icon(
        imageVector = Icons.Default.LocationOn,
        contentDescription = "Location",
        tint = theme3D.primaryLight,
        modifier = Modifier.size(16.dp)
      )
      Spacer(modifier = Modifier.width(4.dp))
      Text(
        text = HemantaResumeData.FULL_ADDRESS,
        fontSize = 12.sp,
        color = theme3D.textSecondary
      )
    }

    Spacer(modifier = Modifier.height(12.dp))

    // Objective Statement Card
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(12.dp))
        .background(theme3D.background.copy(alpha = 0.6f))
        .border(1.dp, theme3D.border, RoundedCornerShape(12.dp))
        .padding(12.dp)
    ) {
      Text(
        text = "\"${HemantaResumeData.OBJECTIVE}\"",
        fontSize = 12.sp,
        lineHeight = 18.sp,
        color = theme3D.textSecondary
      )
    }

    Spacer(modifier = Modifier.height(16.dp))

    // CTA Action Buttons
    FlowRow(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      Button(
        onClick = onHireClick,
        colors = ButtonDefaults.buttonColors(containerColor = theme3D.primary),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.testTag("hire_hemanta_cta")
      ) {
        Icon(Icons.Default.Work, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text("Hire Hemanta", fontWeight = FontWeight.Bold)
      }

      OutlinedButton(
        onClick = {
          val intent = Intent(Intent.ACTION_DIAL).apply {
            data = Uri.parse("tel:${HemantaResumeData.PHONE_NUMBER}")
          }
          context.startActivity(intent)
        },
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, theme3D.primary)
      ) {
        Icon(Icons.Default.Call, contentDescription = null, tint = theme3D.primaryLight, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text(HemantaResumeData.PHONE_NUMBER, color = theme3D.primaryLight)
      }

      OutlinedButton(
        onClick = {
          val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("mailto:${HemantaResumeData.EMAIL_ADDRESS}")
          }
          context.startActivity(intent)
        },
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, theme3D.border)
      ) {
        Icon(Icons.Default.Email, contentDescription = null, tint = theme3D.textSecondary, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text(HemantaResumeData.EMAIL_ADDRESS, color = theme3D.textSecondary)
      }
    }
  }
}

@Composable
private fun KeyMetricsSection(theme3D: Theme3DConfig) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    HemantaResumeData.keyMetrics.forEach { (value, label) ->
      Card(
        modifier = Modifier.weight(1f),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = theme3D.surfaceCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, theme3D.border)
      ) {
        Column(
          modifier = Modifier.padding(10.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Text(
            text = value,
            fontSize = 15.sp,
            fontWeight = FontWeight.Black,
            color = theme3D.primaryLight
          )
          Spacer(modifier = Modifier.height(2.dp))
          Text(
            text = label,
            fontSize = 10.sp,
            color = theme3D.textSecondary,
            lineHeight = 12.sp
          )
        }
      }
    }
  }
}

@Composable
private fun WorkExperienceSection(theme3D: Theme3DConfig) {
  Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = "PROFESSIONAL EXPERIENCE",
        fontFamily = FontFamily.Monospace,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        color = theme3D.primaryLight
      )
      Text(
        text = "Verified Career Records",
        fontSize = 11.sp,
        color = theme3D.textMuted
      )
    }

    HemantaResumeData.experiences.forEach { exp ->
      var isExpanded by remember { mutableStateOf(true) }

      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = theme3D.surfaceCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, theme3D.border)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = exp.role,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
              )
              Text(
                text = "${exp.company} • ${exp.location}",
                fontSize = 13.sp,
                color = theme3D.primaryLight,
                fontWeight = FontWeight.SemiBold
              )
              Text(
                text = exp.periodYears,
                fontSize = 11.sp,
                color = theme3D.accent
              )
            }

            IconButton(
              onClick = { isExpanded = !isExpanded },
              modifier = Modifier.size(28.dp)
            ) {
              Icon(
                imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                contentDescription = "Expand",
                tint = theme3D.textSecondary
              )
            }
          }

          AnimatedVisibility(visible = isExpanded) {
            Column(modifier = Modifier.padding(top = 10.dp)) {
              exp.highlights.forEach { bullet ->
                Row(
                  modifier = Modifier.padding(vertical = 3.dp),
                  verticalAlignment = Alignment.Top
                ) {
                  Text("•", color = theme3D.primary, fontWeight = FontWeight.Bold, modifier = Modifier.padding(end = 6.dp))
                  Text(bullet, fontSize = 12.sp, lineHeight = 17.sp, color = theme3D.textSecondary)
                }
              }

              Spacer(modifier = Modifier.height(10.dp))

              // Tags
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
              ) {
                exp.tags.forEach { tag ->
                  Box(
                    modifier = Modifier
                      .clip(RoundedCornerShape(6.dp))
                      .background(theme3D.surface)
                      .border(1.dp, theme3D.border, RoundedCornerShape(6.dp))
                      .padding(horizontal = 8.dp, vertical = 3.dp)
                  ) {
                    Text(tag, fontSize = 10.sp, color = theme3D.primaryLight)
                  }
                }
              }

              Spacer(modifier = Modifier.height(6.dp))
              Text(
                text = "Key Result: ${exp.metrics}",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = theme3D.accent
              )
            }
          }
        }
      }
    }
  }
}

@Composable
private fun SkillsAndSoftwareSection(theme3D: Theme3DConfig) {
  Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
    Text(
      text = "SKILLS & ACCOUNTING SOFTWARE",
      fontFamily = FontFamily.Monospace,
      fontSize = 11.sp,
      fontWeight = FontWeight.Bold,
      color = theme3D.primaryLight
    )

    HemantaResumeData.skillCategories.forEach { category ->
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = theme3D.surfaceCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, theme3D.border)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Text(
            text = category.categoryName,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
          )
          Spacer(modifier = Modifier.height(10.dp))

          category.skills.forEach { skill ->
            Column(modifier = Modifier.padding(vertical = 4.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Text(skill.name, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = theme3D.textPrimary)
                  Spacer(modifier = Modifier.width(6.dp))
                  Text("(${skill.tag})", fontSize = 10.sp, color = theme3D.primaryLight)
                }
                Text("${skill.proficiency}%", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = theme3D.accent)
              }

              Spacer(modifier = Modifier.height(4.dp))

              LinearProgressIndicator(
                progress = { skill.proficiency / 100f },
                modifier = Modifier
                  .fillMaxWidth()
                  .height(5.dp)
                  .clip(RoundedCornerShape(3.dp)),
                color = theme3D.primary,
                trackColor = theme3D.surface
              )

              Text(
                text = skill.detail,
                fontSize = 10.sp,
                color = theme3D.textMuted,
                modifier = Modifier.padding(top = 2.dp)
              )
            }
          }
        }
      }
    }
  }
}

@Composable
private fun EducationAndCertificationsSection(theme3D: Theme3DConfig) {
  Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
    Text(
      text = "EDUCATION & CREDENTIALS",
      fontFamily = FontFamily.Monospace,
      fontSize = 11.sp,
      fontWeight = FontWeight.Bold,
      color = theme3D.primaryLight
    )

    // Education
    HemantaResumeData.educations.forEach { edu ->
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = theme3D.surfaceCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, theme3D.border)
      ) {
        Row(
          modifier = Modifier.padding(12.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box(
            modifier = Modifier
              .size(36.dp)
              .clip(CircleShape)
              .background(theme3D.primary.copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
          ) {
            Icon(Icons.Default.School, contentDescription = null, tint = theme3D.primaryLight, modifier = Modifier.size(18.dp))
          }
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Text(edu.degree, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text("${edu.institution} (${edu.universityOrBoard})", fontSize = 11.sp, color = theme3D.textSecondary)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              Text(edu.scoreOrCgpa, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = theme3D.accent)
              Text("•", color = theme3D.textMuted)
              Text(edu.year, fontSize = 11.sp, color = theme3D.textMuted)
            }
          }
        }
      }
    }

    // Certifications
    Text(
      text = "TECHNICAL DIPLOMAS & CERTIFICATIONS",
      fontFamily = FontFamily.Monospace,
      fontSize = 11.sp,
      fontWeight = FontWeight.Bold,
      color = theme3D.secondary,
      modifier = Modifier.padding(top = 6.dp)
    )

    HemantaResumeData.certifications.forEach { cert ->
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = theme3D.surfaceCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, theme3D.border)
      ) {
        Row(
          modifier = Modifier.padding(12.dp),
          verticalAlignment = Alignment.Top
        ) {
          Box(
            modifier = Modifier
              .size(36.dp)
              .clip(CircleShape)
              .background(theme3D.secondary.copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = when (cert.iconName) {
                "Build" -> Icons.Default.Build
                "Terminal" -> Icons.Default.Computer
                else -> Icons.Default.Computer
              },
              contentDescription = null,
              tint = theme3D.secondary,
              modifier = Modifier.size(18.dp)
            )
          }
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(cert.code, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
              Text(cert.institution, fontSize = 10.sp, color = theme3D.textMuted)
            }
            Text(cert.title, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = theme3D.primaryLight)
            Text(cert.description, fontSize = 11.sp, color = theme3D.textSecondary, modifier = Modifier.padding(top = 2.dp))
          }
        }
      }
    }
  }
}

@Composable
private fun OfficialDeclarationCard(
  theme3D: Theme3DConfig,
  onViewFull: () -> Unit
) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(18.dp),
    colors = CardDefaults.cardColors(containerColor = theme3D.surfaceCard),
    border = androidx.compose.foundation.BorderStroke(1.dp, theme3D.border)
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.CheckCircle, contentDescription = null, tint = theme3D.accent, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text("OFFICIAL APPLICANT DECLARATION", fontFamily = FontFamily.Monospace, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = theme3D.accent)
        }
        Text("Signed", fontSize = 11.sp, color = theme3D.textMuted)
      }

      Spacer(modifier = Modifier.height(8.dp))
      Text(
        text = "\"${HemantaResumeData.DECLARATION_STATEMENT}\"",
        fontSize = 12.sp,
        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
        color = theme3D.textPrimary
      )

      Spacer(modifier = Modifier.height(10.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text("Place: JORHAT, ASSAM", fontSize = 11.sp, color = theme3D.textSecondary)
        Text("(HEMANTA DUTTA)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = theme3D.primaryLight)
      }
    }
  }
}

@Composable
private fun WebsiteFooter(theme3D: Theme3DConfig) {
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 12.dp),
    horizontalAlignment = Alignment.CenterHorizontally
  ) {
    Text(
      text = "Hemanta Dutta • 3D Portfolio Website",
      fontSize = 12.sp,
      fontWeight = FontWeight.Bold,
      color = theme3D.textSecondary
    )
    Text(
      text = "House No. 11, Krishana Guru Sewashram, Jorhat, Assam - 785007",
      fontSize = 10.sp,
      color = theme3D.textMuted
    )
    Text(
      text = "Tally ERP • Ezy Rakod • GST Filing • B.Com (Honors) Dibrugarh University",
      fontSize = 10.sp,
      color = theme3D.textMuted
    )
  }
}
