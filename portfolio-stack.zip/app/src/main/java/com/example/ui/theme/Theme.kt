package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
  primary = TechCyanPrimary,
  onPrimary = Color(0xFF002A3D),
  primaryContainer = Color(0xFF004D6E),
  onPrimaryContainer = TechCyanLight,
  secondary = TechVioletSecondary,
  onSecondary = Color(0xFF1E1B4B),
  secondaryContainer = Color(0xFF312E81),
  onSecondaryContainer = TechVioletLight,
  tertiary = TechPinkTertiary,
  onTertiary = Color(0xFF4A042A),
  background = TechDarkBackground,
  onBackground = TextPrimaryDark,
  surface = TechDarkSurface,
  onSurface = TextPrimaryDark,
  surfaceVariant = TechDarkSurfaceVariant,
  onSurfaceVariant = TextSecondaryDark,
  outline = TechBorderDark,
  outlineVariant = TechBorderGlow
)

private val LightColorScheme = lightColorScheme(
  primary = TechLightPrimary,
  onPrimary = Color.White,
  primaryContainer = Color(0xFFBAE6FD),
  onPrimaryContainer = Color(0xFF0369A1),
  secondary = TechLightSecondary,
  onSecondary = Color.White,
  secondaryContainer = Color(0xFFE0E7FF),
  onSecondaryContainer = Color(0xFF3730A3),
  tertiary = TechLightTertiary,
  background = TechLightBackground,
  onBackground = TextPrimaryLight,
  surface = TechLightSurface,
  onSurface = TextPrimaryLight,
  surfaceVariant = TechLightSurfaceVariant,
  onSurfaceVariant = TextSecondaryLight,
  outline = Color(0xFFCBD5E1)
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false, // Default to our cohesive luxury tech scheme
  content: @Composable () -> Unit
) {
  val colorScheme = when {
    dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
      val context = LocalContext.current
      if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    }
    darkTheme -> DarkColorScheme
    else -> DarkColorScheme // Portfolio looks best in dark cyberpunk/modern luxury mode
  }

  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    content = content
  )
}
