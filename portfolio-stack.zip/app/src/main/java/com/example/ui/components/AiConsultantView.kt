package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AiConsultResult
import com.example.data.GeminiRepository
import com.example.ui.theme.LocalTheme3D
import kotlinx.coroutines.launch

@Composable
fun AiConsultantView(
  modifier: Modifier = Modifier,
  geminiRepository: GeminiRepository = remember { GeminiRepository() }
) {
  val theme3D = LocalTheme3D.current
  val scope = rememberCoroutineScope()
  val clipboardManager = LocalClipboardManager.current
  var userPrompt by remember { mutableStateOf("") }
  var isLoading by remember { mutableStateOf(false) }
  var currentResult by remember {
    mutableStateOf<AiConsultResult?>(null)
  }

  val suggestedQueries = listOf(
    "Why should an organization hire Hemanta Dutta as an Accountant?",
    "Draft a tailored cover letter for a Senior Tax & Tally Specialist position.",
    "Explain Hemanta's GST filing & Bank Reconciliation methodology.",
    "Generate 3 challenging accounting interview questions for Hemanta."
  )

  val infiniteTransition = rememberInfiniteTransition(label = "pulse_glow")
  val pulseAlpha by infiniteTransition.animateFloat(
    initialValue = 0.3f,
    targetValue = 0.9f,
    animationSpec = infiniteRepeatable(
      animation = tween(1500, easing = LinearEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "pulse_alpha"
  )

  fun executeQuery(query: String) {
    if (query.isBlank() || isLoading) return
    scope.launch {
      isLoading = true
      userPrompt = query
      val res = geminiRepository.askHighThinkingArchitect(query)
      currentResult = res
      isLoading = false
    }
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(theme3D.background)
      .padding(16.dp)
      .verticalScroll(rememberScrollState()),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Top Hero Card
    Card(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(20.dp),
      colors = CardDefaults.cardColors(containerColor = theme3D.surfaceCard),
      border = androidx.compose.foundation.BorderStroke(
        1.dp,
        Brush.horizontalGradient(listOf(theme3D.primary, theme3D.secondary))
      )
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(theme3D.primary.copy(alpha = 0.2f)),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.Psychology,
                contentDescription = null,
                tint = theme3D.primaryLight,
                modifier = Modifier.size(24.dp)
              )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = "AI Career & Tax Consultant",
                style = MaterialTheme.typography.titleMedium.copy(
                  fontWeight = FontWeight.Bold,
                  color = Color.White
                )
              )
              Text(
                text = "Powered by Gemini 3.1 Pro • Thinking Level: HIGH",
                style = MaterialTheme.typography.bodySmall.copy(color = theme3D.textSecondary)
              )
            }
          }

          // Thinking Badge
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = theme3D.surface,
            border = androidx.compose.foundation.BorderStroke(
              1.dp,
              theme3D.primary.copy(alpha = pulseAlpha)
            )
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Box(
                modifier = Modifier
                  .size(6.dp)
                  .clip(CircleShape)
                  .background(theme3D.primary)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "THINKING: HIGH",
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = theme3D.primaryLight
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))
        Text(
          text = "Ask evaluating questions regarding Hemanta Dutta's credentials, generate tailored cover letters, analyze GST return workflows, or simulate high-rigor accounting interviews.",
          style = MaterialTheme.typography.bodySmall.copy(
            color = theme3D.textSecondary,
            lineHeight = 18.sp
          )
        )
      }
    }

    // Input card
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(16.dp))
        .background(theme3D.surfaceCard)
        .border(1.dp, theme3D.border, RoundedCornerShape(16.dp))
        .padding(14.dp)
    ) {
      Text(
        text = "Ask AI Consultant:",
        fontSize = 12.sp,
        fontWeight = FontWeight.SemiBold,
        color = theme3D.textSecondary
      )
      Spacer(modifier = Modifier.height(8.dp))

      OutlinedTextField(
        value = userPrompt,
        onValueChange = { userPrompt = it },
        placeholder = {
          Text(
            "e.g., Why is Hemanta a standout candidate for an Accountant role?",
            fontSize = 13.sp,
            color = theme3D.textMuted
          )
        },
        modifier = Modifier
          .fillMaxWidth()
          .testTag("ai_consultant_input"),
        colors = OutlinedTextFieldDefaults.colors(
          focusedTextColor = Color.White,
          unfocusedTextColor = Color.White,
          focusedBorderColor = theme3D.primary,
          unfocusedBorderColor = theme3D.border,
          cursorColor = theme3D.primary
        ),
        shape = RoundedCornerShape(12.dp),
        maxLines = 3
      )

      Spacer(modifier = Modifier.height(10.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "Model: gemini-3.1-pro-preview",
          fontFamily = FontFamily.Monospace,
          fontSize = 10.sp,
          color = theme3D.textMuted
        )

        Button(
          onClick = { executeQuery(userPrompt) },
          enabled = userPrompt.isNotBlank() && !isLoading,
          colors = ButtonDefaults.buttonColors(
            containerColor = theme3D.primary,
            disabledContainerColor = theme3D.surface
          ),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier.testTag("ai_consultant_submit_btn")
        ) {
          if (isLoading) {
            CircularProgressIndicator(
              color = Color.White,
              modifier = Modifier.size(16.dp),
              strokeWidth = 2.dp
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text("Reasoning...", fontSize = 12.sp)
          } else {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.Send,
              contentDescription = "Send",
              modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text("Analyze", fontWeight = FontWeight.Bold, fontSize = 12.sp)
          }
        }
      }
    }

    // Suggested Questions Chips
    Column {
      Text(
        text = "RECOMMENDED EVALUATION PROMPTS:",
        fontFamily = FontFamily.Monospace,
        fontSize = 10.sp,
        fontWeight = FontWeight.Bold,
        color = theme3D.primaryLight
      )
      Spacer(modifier = Modifier.height(8.dp))

      Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        suggestedQueries.forEach { query ->
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = theme3D.surfaceCard,
            border = androidx.compose.foundation.BorderStroke(1.dp, theme3D.border),
            modifier = Modifier
              .fillMaxWidth()
              .clickable { executeQuery(query) }
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = null,
                tint = theme3D.accent,
                modifier = Modifier.size(14.dp)
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = query,
                fontSize = 11.sp,
                color = theme3D.textSecondary,
                lineHeight = 15.sp
              )
            }
          }
        }
      }
    }

    // Response Container
    AnimatedVisibility(visible = currentResult != null || isLoading) {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = theme3D.surfaceCard),
        border = androidx.compose.foundation.BorderStroke(
          1.dp,
          if (currentResult?.success == true) theme3D.accent.copy(alpha = 0.4f) else theme3D.border
        )
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.Code,
                contentDescription = null,
                tint = theme3D.primaryLight,
                modifier = Modifier.size(18.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "AI CONSULTANT EVALUATION",
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = theme3D.primaryLight
              )
            }

            if (currentResult != null) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = Icons.Default.Speed,
                  contentDescription = null,
                  tint = theme3D.accent,
                  modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                  text = "${currentResult?.durationMs}ms",
                  fontFamily = FontFamily.Monospace,
                  fontSize = 11.sp,
                  color = theme3D.accent
                )
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(
                  onClick = {
                    currentResult?.answer?.let {
                      clipboardManager.setText(AnnotatedString(it))
                    }
                  },
                  modifier = Modifier.size(28.dp)
                ) {
                  Icon(
                    imageVector = Icons.Default.ContentCopy,
                    contentDescription = "Copy",
                    tint = theme3D.textSecondary,
                    modifier = Modifier.size(16.dp)
                  )
                }
              }
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          if (isLoading) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 24.dp),
              horizontalArrangement = Arrangement.Center,
              verticalAlignment = Alignment.CenterVertically
            ) {
              CircularProgressIndicator(
                color = theme3D.primary,
                modifier = Modifier.size(24.dp),
                strokeWidth = 2.dp
              )
              Spacer(modifier = Modifier.width(12.dp))
              Text(
                text = "Reasoning with Gemini 3.1 Pro (Thinking Level: HIGH)...",
                style = MaterialTheme.typography.bodyMedium.copy(color = theme3D.textSecondary)
              )
            }
          } else if (currentResult != null) {
            val result = currentResult!!
            if (result.success) {
              Text(
                text = result.answer,
                style = MaterialTheme.typography.bodyMedium.copy(
                  color = Color.White,
                  lineHeight = 20.sp
                )
              )
            } else {
              Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                  text = "Notice",
                  fontWeight = FontWeight.Bold,
                  color = theme3D.primaryLight
                )
                Text(
                  text = result.errorMessage ?: "An unexpected error occurred.",
                  style = MaterialTheme.typography.bodySmall.copy(color = theme3D.textSecondary)
                )
              }
            }
          }
        }
      }
    }
  }
}
