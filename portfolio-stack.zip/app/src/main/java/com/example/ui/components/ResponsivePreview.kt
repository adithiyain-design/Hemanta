package com.example.ui.components

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tablet
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PortfolioData
import com.example.ui.theme.TechCyanLight
import com.example.ui.theme.TechCyanPrimary
import com.example.ui.theme.TechDarkSurfaceCard
import com.example.ui.theme.TechEmeraldAccent
import com.example.ui.theme.TechPinkTertiary
import com.example.ui.theme.TechVioletSecondary

enum class DeviceViewport(val label: String, val widthPx: String, val layoutDesc: String) {
  DESKTOP("Desktop", "1440px", "3-Column Grid with Floating Turntable"),
  TABLET("Tablet", "768px", "2-Column Adaptive Split View"),
  MOBILE("Mobile", "375px", "Single Column Full-Bleed Stack")
}

@Composable
fun ResponsiveUxShowcase(modifier: Modifier = Modifier) {
  var currentViewport by remember { mutableStateOf(DeviceViewport.DESKTOP) }

  Card(
    modifier = modifier.fillMaxWidth(),
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(containerColor = TechDarkSurfaceCard),
    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B))
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .size(36.dp)
              .clip(CircleShape)
              .background(TechEmeraldAccent.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.Computer,
              contentDescription = "Responsive UX",
              tint = TechEmeraldAccent,
              modifier = Modifier.size(20.dp)
            )
          }
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Text(
              text = "Responsive UX & Delivery",
              style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = Color.White
              )
            )
            Text(
              text = "Adaptive multi-screen layout simulation",
              style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFF94A3B8))
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Viewport Switcher Pills
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(12.dp))
          .background(Color(0xFF0F172A))
          .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
      ) {
        DeviceViewport.values().forEach { viewport ->
          val isSelected = currentViewport == viewport
          Box(
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(8.dp))
              .background(if (isSelected) TechCyanPrimary.copy(alpha = 0.2f) else Color.Transparent)
              .border(
                1.dp,
                if (isSelected) TechCyanPrimary else Color.Transparent,
                RoundedCornerShape(8.dp)
              )
              .clickable { currentViewport = viewport }
              .padding(vertical = 8.dp)
              .testTag("viewport_${viewport.name.lowercase()}"),
            contentAlignment = Alignment.Center
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = when (viewport) {
                  DeviceViewport.DESKTOP -> Icons.Default.Computer
                  DeviceViewport.TABLET -> Icons.Default.Tablet
                  DeviceViewport.MOBILE -> Icons.Default.PhoneAndroid
                },
                contentDescription = null,
                tint = if (isSelected) TechCyanLight else Color(0xFF64748B),
                modifier = Modifier.size(14.dp)
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = viewport.label,
                fontSize = 11.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                color = if (isSelected) Color.White else Color(0xFF94A3B8)
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Simulated Device Frame
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(14.dp))
          .background(Color(0xFF070B12))
          .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(14.dp))
          .padding(12.dp)
          .animateContentSize()
      ) {
        // Frame Top Bar
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Color(0xFFEF4444)))
            Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Color(0xFFF59E0B)))
            Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Color(0xFF10B981)))
          }

          Text(
            text = "Viewport: ${currentViewport.widthPx} • ${currentViewport.layoutDesc}",
            fontFamily = FontFamily.Monospace,
            fontSize = 9.sp,
            color = Color(0xFF64748B)
          )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Dynamic Responsive Mockup layout inside frame
        when (currentViewport) {
          DeviceViewport.DESKTOP -> {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              // Left Column: Navigation & Hero Pitch
              Box(
                modifier = Modifier
                  .weight(1.2f)
                  .height(100.dp)
                  .clip(RoundedCornerShape(8.dp))
                  .background(Color(0xFF0F172A))
                  .padding(8.dp)
              ) {
                Column {
                  Text("HERO 3D SHOWCASE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TechCyanLight)
                  Text("React 19 • GSAP • WebGL", fontSize = 8.sp, color = Color(0xFF94A3B8))
                  Spacer(modifier = Modifier.height(6.dp))
                  Text("Kinetic 360 Turntable with glass dispersion", fontSize = 8.sp, color = Color.White)
                }
              }
              // Middle Column: Featured Project
              Box(
                modifier = Modifier
                  .weight(1f)
                  .height(100.dp)
                  .clip(RoundedCornerShape(8.dp))
                  .background(Color(0xFF131F37))
                  .padding(8.dp)
              ) {
                Column {
                  Text("DESIGN TOKENS", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TechVioletSecondary)
                  Text("Figma Token Sync", fontSize = 8.sp, color = Color(0xFF94A3B8))
                  Spacer(modifier = Modifier.height(6.dp))
                  Text("8-point modular grid & WCAG AAA colors", fontSize = 8.sp, color = Color.White)
                }
              }
              // Right Column: Live Metrics
              Box(
                modifier = Modifier
                  .weight(0.9f)
                  .height(100.dp)
                  .clip(RoundedCornerShape(8.dp))
                  .background(Color(0xFF142426))
                  .padding(8.dp)
              ) {
                Column {
                  Text("DELIVERY", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TechEmeraldAccent)
                  Text("LCP: 0.72s", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                  Text("FID: 18ms", fontSize = 10.sp, color = TechEmeraldAccent)
                  Text("CLS: 0.00", fontSize = 10.sp, color = TechEmeraldAccent)
                }
              }
            }
          }

          DeviceViewport.TABLET -> {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                Box(
                  modifier = Modifier
                    .weight(1f)
                    .height(65.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF0F172A))
                    .padding(8.dp)
                ) {
                  Text("HERO 3D (Two-Column Adaptive)", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = TechCyanLight)
                }
                Box(
                  modifier = Modifier
                    .weight(1f)
                    .height(65.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF131F37))
                    .padding(8.dp)
                ) {
                  Text("DESIGN TOKENS (Auto-Wrap)", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = TechVioletSecondary)
                }
              }
              Box(
                modifier = Modifier
                  .fillMaxWidth()
                  .height(40.dp)
                  .clip(RoundedCornerShape(8.dp))
                  .background(Color(0xFF142426))
                  .padding(8.dp)
              ) {
                Text("PERFORMANCE DOCK: LCP 0.74s • 60 FPS compositor", fontSize = 9.sp, color = TechEmeraldAccent)
              }
            }
          }

          DeviceViewport.MOBILE -> {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
              Box(
                modifier = Modifier
                  .fillMaxWidth()
                  .height(44.dp)
                  .clip(RoundedCornerShape(8.dp))
                  .background(Color(0xFF0F172A))
                  .padding(8.dp)
              ) {
                Text("MOBILE 375px: 360° Touch Orbit (Full Bleed)", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = TechCyanLight)
              }
              Box(
                modifier = Modifier
                  .fillMaxWidth()
                  .height(44.dp)
                  .clip(RoundedCornerShape(8.dp))
                  .background(Color(0xFF131F37))
                  .padding(8.dp)
              ) {
                Text("MOBILE 375px: 48dp Touch Targets & Sticky Footer", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = TechVioletSecondary)
              }
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Core Web Vitals Benchmark Bar
      Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFF0F172A),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B))
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(10.dp),
          horizontalArrangement = Arrangement.SpaceAround,
          verticalAlignment = Alignment.CenterVertically
        ) {
          MetricChip(label = "LCP", value = "0.72s", status = "Good")
          MetricChip(label = "INP", value = "22ms", status = "Fast")
          MetricChip(label = "CLS", value = "0.00", status = "Zero")
          MetricChip(label = "BUNDLE", value = "82 kB", status = "Gzip")
        }
      }
    }
  }
}

@Composable
private fun MetricChip(label: String, value: String, status: String) {
  Column(horizontalAlignment = Alignment.CenterHorizontally) {
    Text(
      text = label,
      fontFamily = FontFamily.Monospace,
      fontSize = 9.sp,
      color = Color(0xFF64748B)
    )
    Text(
      text = value,
      fontWeight = FontWeight.Bold,
      fontSize = 12.sp,
      color = Color.White
    )
    Row(verticalAlignment = Alignment.CenterVertically) {
      Box(modifier = Modifier.size(5.dp).clip(CircleShape).background(TechEmeraldAccent))
      Spacer(modifier = Modifier.width(3.dp))
      Text(
        text = status,
        fontSize = 9.sp,
        color = TechEmeraldAccent
      )
    }
  }
}
