package com.example.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.material.icons.outlined.Calculate
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.Psychology
import androidx.compose.material.icons.outlined.ViewInAr
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.HemantaResumeData
import com.example.ui.components.AiConsultantView
import com.example.ui.components.GstTaxCalculator
import com.example.ui.components.Interactive3DHeroSection
import com.example.ui.components.Resume3DWebsiteView
import com.example.ui.theme.LocalTheme3D
import com.example.ui.theme.Theme3DConfig
import com.example.ui.theme.Theme3DPresets

enum class NavDestination(
  val label: String,
  val selectedIcon: ImageVector,
  val unselectedIcon: ImageVector,
  val testTag: String
) {
  WEBSITE(
    label = "3D Website",
    selectedIcon = Icons.Filled.Language,
    unselectedIcon = Icons.Outlined.Language,
    testTag = "nav_website"
  ),
  STUDIO_3D(
    label = "3D Studio",
    selectedIcon = Icons.Filled.ViewInAr,
    unselectedIcon = Icons.Outlined.ViewInAr,
    testTag = "nav_3d_studio"
  ),
  TAX_TOOLS(
    label = "GST & Ledger",
    selectedIcon = Icons.Filled.Calculate,
    unselectedIcon = Icons.Outlined.Calculate,
    testTag = "nav_tax_tools"
  ),
  AI_CAREER(
    label = "AI Career",
    selectedIcon = Icons.Filled.Psychology,
    unselectedIcon = Icons.Outlined.Psychology,
    testTag = "nav_ai_career"
  )
}

@Composable
fun PortfolioStackApp() {
  var current3DTheme by remember { mutableStateOf(Theme3DPresets.CYBER_OBSIDIAN) }
  var currentDestination by remember { mutableStateOf(NavDestination.WEBSITE) }
  var showThemeDialog by remember { mutableStateOf(false) }

  CompositionLocalProvider(LocalTheme3D provides current3DTheme) {
    val theme3D = LocalTheme3D.current

    Scaffold(
      modifier = Modifier
        .fillMaxSize()
        .background(theme3D.background),
      containerColor = theme3D.background,
      topBar = {
        Surface(
          color = theme3D.surfaceCard,
          border = androidx.compose.foundation.BorderStroke(1.dp, theme3D.border),
          modifier = Modifier.fillMaxWidth().statusBarsPadding()
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column {
              Text(
                text = "HEMANTA DUTTA",
                fontSize = 14.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.sp,
                color = Color.White
              )
              Text(
                text = "3D Resume Portfolio • ${theme3D.name}",
                fontSize = 11.sp,
                color = theme3D.primaryLight
              )
            }

            // Quick 3D Theme Switcher Action
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .background(theme3D.primary.copy(alpha = 0.18f))
                .border(1.dp, theme3D.primary.copy(alpha = 0.4f), RoundedCornerShape(20.dp))
                .clickable { showThemeDialog = true }
                .padding(horizontal = 10.dp, vertical = 6.dp)
                .testTag("theme_switcher_top_btn")
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = Icons.Default.Palette,
                  contentDescription = "Themes",
                  tint = theme3D.primaryLight,
                  modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = "Themes 3D",
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  color = theme3D.primaryLight
                )
              }
            }
          }
        }
      },
      bottomBar = {
        NavigationBar(
          modifier = Modifier
            .navigationBarsPadding()
            .testTag("portfolio_bottom_nav"),
          containerColor = theme3D.surfaceCard,
          tonalElevation = 8.dp
        ) {
          NavDestination.values().forEach { destination ->
            val isSelected = currentDestination == destination
            NavigationBarItem(
              selected = isSelected,
              onClick = { currentDestination = destination },
              icon = {
                Icon(
                  imageVector = if (isSelected) destination.selectedIcon else destination.unselectedIcon,
                  contentDescription = destination.label,
                  modifier = Modifier.size(22.dp)
                )
              },
              label = {
                Text(
                  text = destination.label,
                  fontSize = 11.sp,
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                )
              },
              colors = NavigationBarItemDefaults.colors(
                selectedIconColor = theme3D.primaryLight,
                selectedTextColor = theme3D.primaryLight,
                unselectedIconColor = theme3D.textMuted,
                unselectedTextColor = theme3D.textMuted,
                indicatorColor = theme3D.primary.copy(alpha = 0.2f)
              ),
              modifier = Modifier.testTag(destination.testTag)
            )
          }
        }
      }
    ) { innerPadding ->
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(innerPadding)
      ) {
        AnimatedContent(
          targetState = currentDestination,
          transitionSpec = { fadeIn() togetherWith fadeOut() },
          label = "screen_transition"
        ) { destination ->
          when (destination) {
            NavDestination.WEBSITE -> {
              Resume3DWebsiteView(
                onThemeSelected = { newTheme -> current3DTheme = newTheme }
              )
            }
            NavDestination.STUDIO_3D -> {
              Studio3DScreen(
                theme3D = theme3D,
                onSelectTheme = { current3DTheme = it }
              )
            }
            NavDestination.TAX_TOOLS -> {
              TaxAndLedgerScreen(theme3D = theme3D)
            }
            NavDestination.AI_CAREER -> {
              AiConsultantView()
            }
          }
        }
      }
    }

    // 3D Themes Dialog
    if (showThemeDialog) {
      AlertDialog(
        onDismissRequest = { showThemeDialog = false },
        title = {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Palette, contentDescription = null, tint = theme3D.primaryLight)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Select 3D Theme", fontWeight = FontWeight.Bold)
          }
        },
        text = {
          Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
              "Switching the 3D theme dynamically transforms all volumetric lighting, material shaders, and color palettes across the portfolio website.",
              fontSize = 12.sp,
              color = theme3D.textSecondary
            )

            Theme3DPresets.ALL_THEMES.forEach { preset ->
              val isSelected = preset.id == current3DTheme.id
              Box(
                modifier = Modifier
                  .fillMaxWidth()
                  .clip(RoundedCornerShape(12.dp))
                  .background(if (isSelected) preset.primary.copy(alpha = 0.2f) else theme3D.surface)
                  .border(
                    1.dp,
                    if (isSelected) preset.primary else theme3D.border,
                    RoundedCornerShape(12.dp)
                  )
                  .clickable {
                    current3DTheme = preset
                    showThemeDialog = false
                  }
                  .padding(12.dp)
              ) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                      modifier = Modifier
                        .size(16.dp)
                        .clip(CircleShape)
                        .background(preset.primary)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                      Text(
                        text = preset.name,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                      )
                      Text(
                        text = preset.tagLine,
                        fontSize = 10.sp,
                        color = theme3D.textSecondary
                      )
                    }
                  }

                  if (isSelected) {
                    Surface(
                      shape = RoundedCornerShape(6.dp),
                      color = preset.primary.copy(alpha = 0.3f)
                    ) {
                      Text(
                        text = "ACTIVE",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        color = preset.primaryLight,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                      )
                    }
                  }
                }
              }
            }
          }
        },
        confirmButton = {
          Button(
            onClick = { showThemeDialog = false },
            colors = ButtonDefaults.buttonColors(containerColor = theme3D.primary)
          ) {
            Text("Done")
          }
        },
        containerColor = theme3D.surfaceCard,
        titleContentColor = Color.White
      )
    }
  }
}

@Composable
private fun Studio3DScreen(
  theme3D: Theme3DConfig,
  onSelectTheme: (Theme3DConfig) -> Unit
) {
  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(theme3D.background)
      .verticalScroll(rememberScrollState())
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Top Hero
    Interactive3DHeroSection(
      title = "3D Interactive Model Studio",
      subtitle = "Spatial Presentation & Geometry Inspection"
    )

    // 3D Theme Gallery
    Card(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(18.dp),
      colors = CardDefaults.cardColors(containerColor = theme3D.surfaceCard),
      border = androidx.compose.foundation.BorderStroke(1.dp, theme3D.border)
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Text(
          text = "3D THEMES GALLERY",
          fontFamily = FontFamily.Monospace,
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
          color = theme3D.primaryLight
        )
        Text(
          text = "Tap to switch the visual 3D universe across all portfolio screens:",
          fontSize = 12.sp,
          color = theme3D.textSecondary,
          modifier = Modifier.padding(top = 2.dp)
        )

        Spacer(modifier = Modifier.height(12.dp))

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Theme3DPresets.ALL_THEMES.forEach { preset ->
            val isCurrent = preset.id == theme3D.id
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(if (isCurrent) preset.primary.copy(alpha = 0.2f) else theme3D.surface)
                .border(
                  1.dp,
                  if (isCurrent) preset.primary else theme3D.border,
                  RoundedCornerShape(12.dp)
                )
                .clickable { onSelectTheme(preset) }
                .padding(12.dp)
            ) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Box(
                    modifier = Modifier
                      .size(24.dp)
                      .clip(CircleShape)
                      .background(preset.primary),
                    contentAlignment = Alignment.Center
                  ) {
                    Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(preset.secondary))
                  }
                  Spacer(modifier = Modifier.width(12.dp))
                  Column {
                    Text(preset.name, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.White)
                    Text(preset.tagLine, fontSize = 11.sp, color = theme3D.textSecondary)
                  }
                }

                Surface(
                  shape = RoundedCornerShape(8.dp),
                  color = if (isCurrent) preset.primary.copy(alpha = 0.3f) else theme3D.surfaceCard
                ) {
                  Text(
                    text = if (isCurrent) "ACTIVE" else "APPLY",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    color = if (isCurrent) preset.primaryLight else theme3D.textMuted,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                  )
                }
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun TaxAndLedgerScreen(theme3D: Theme3DConfig) {
  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(theme3D.background)
      .verticalScroll(rememberScrollState())
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Live GST Tool
    GstTaxCalculator()

    // 3 Years Accounting Experience Deep Dive
    Card(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(18.dp),
      colors = CardDefaults.cardColors(containerColor = theme3D.surfaceCard),
      border = androidx.compose.foundation.BorderStroke(1.dp, theme3D.border)
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Text(
          text = "TAX FIRM ACCOUNTING PRACTICE (3 YEARS)",
          fontFamily = FontFamily.Monospace,
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
          color = theme3D.primaryLight
        )
        Text(
          text = "Daily financial transaction entry, Tally bookkeeping, and client auditing in Jorhat, Assam",
          fontSize = 12.sp,
          color = theme3D.textSecondary,
          modifier = Modifier.padding(top = 2.dp)
        )

        Spacer(modifier = Modifier.height(12.dp))

        val points = listOf(
          "Bookkeeping & Invoicing" to "Daily ledger postings in Tally ERP 9 / TallyPrime and Ezy Rakod for trading, manufacturing, and service firms.",
          "GST Compliance" to "Preparation and filing of GSTR-1 (outward supplies) and GSTR-3B (monthly summary), Input Tax Credit (ITC) matching with GSTR-2B.",
          "Bank Reconciliation (BRS)" to "Reconciling bank passbooks with cash books to identify timing differences, dishonored instruments, and uncredited deposits.",
          "Financial Reporting" to "Drafting trial balances, profit & loss summaries, balance sheets, and depreciation schedules."
        )

        points.forEach { (title, desc) ->
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 4.dp)
              .clip(RoundedCornerShape(10.dp))
              .background(theme3D.surface)
              .border(1.dp, theme3D.border, RoundedCornerShape(10.dp))
              .padding(10.dp)
          ) {
            Column {
              Text(title, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = theme3D.primaryLight)
              Spacer(modifier = Modifier.height(2.dp))
              Text(desc, fontSize = 11.sp, color = theme3D.textSecondary, lineHeight = 16.sp)
            }
          }
        }
      }
    }
  }
}
