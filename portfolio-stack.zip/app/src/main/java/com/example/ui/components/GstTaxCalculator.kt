package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.HemantaResumeData
import com.example.ui.theme.LocalTheme3D
import java.text.NumberFormat
import java.util.Locale

@Composable
fun GstTaxCalculator(
  modifier: Modifier = Modifier
) {
  val theme3D = LocalTheme3D.current
  val clipboardManager = LocalClipboardManager.current

  var invoiceInput by remember { mutableStateOf("25000") }
  var selectedRate by remember { mutableDoubleStateOf(18.0) }
  var isInterState by remember { mutableStateOf(false) } // Intra-state (CGST+SGST) vs Inter-state (IGST)
  var isCopied by remember { mutableStateOf(false) }

  val taxableAmount = invoiceInput.toDoubleOrNull() ?: 0.0
  val totalTax = taxableAmount * (selectedRate / 100.0)
  val cgst = if (isInterState) 0.0 else totalTax / 2.0
  val sgst = if (isInterState) 0.0 else totalTax / 2.0
  val igst = if (isInterState) totalTax else 0.0
  val grandTotal = taxableAmount + totalTax

  val currencyFormat = NumberFormat.getCurrencyInstance(Locale("en", "IN"))

  Card(
    modifier = modifier.fillMaxWidth(),
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(containerColor = theme3D.surfaceCard),
    border = androidx.compose.foundation.BorderStroke(1.dp, theme3D.border)
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      // Header
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .size(36.dp)
              .clip(CircleShape)
              .background(theme3D.primary.copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.Calculate,
              contentDescription = "GST Tool",
              tint = theme3D.primaryLight,
              modifier = Modifier.size(20.dp)
            )
          }
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Text(
              text = "Live GST & Tax Calculator",
              style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = theme3D.textPrimary
              )
            )
            Text(
              text = "Interactive Tax Consulting & Bookkeeping Sandbox",
              style = MaterialTheme.typography.bodySmall.copy(color = theme3D.textSecondary)
            )
          }
        }

        Surface(
          shape = RoundedCornerShape(8.dp),
          color = theme3D.surface,
          border = androidx.compose.foundation.BorderStroke(1.dp, theme3D.primary.copy(alpha = 0.4f))
        ) {
          Text(
            text = "TALLY READY",
            fontFamily = FontFamily.Monospace,
            fontSize = 9.sp,
            color = theme3D.primaryLight,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Input Field
      Text(
        text = "Enter Taxable Invoice Amount (₹):",
        fontSize = 12.sp,
        fontWeight = FontWeight.SemiBold,
        color = theme3D.textSecondary
      )
      Spacer(modifier = Modifier.height(6.dp))

      OutlinedTextField(
        value = invoiceInput,
        onValueChange = { invoiceInput = it.filter { char -> char.isDigit() || char == '.' } },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = Modifier
          .fillMaxWidth()
          .testTag("gst_invoice_input"),
        colors = OutlinedTextFieldDefaults.colors(
          focusedTextColor = Color.White,
          unfocusedTextColor = Color.White,
          focusedBorderColor = theme3D.primary,
          unfocusedBorderColor = theme3D.border,
          cursorColor = theme3D.primary
        ),
        shape = RoundedCornerShape(12.dp)
      )

      Spacer(modifier = Modifier.height(12.dp))

      // GST Slab Selectors
      Text(
        text = "Select GST Slab Rate:",
        fontSize = 12.sp,
        color = theme3D.textSecondary
      )
      Spacer(modifier = Modifier.height(6.dp))

      Row(
        modifier = Modifier
          .fillMaxWidth()
          .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        listOf(0.0, 5.0, 12.0, 18.0, 28.0).forEach { rate ->
          val isSelected = selectedRate == rate
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(10.dp))
              .background(if (isSelected) theme3D.primary.copy(alpha = 0.25f) else theme3D.surface)
              .border(
                1.dp,
                if (isSelected) theme3D.primary else theme3D.border,
                RoundedCornerShape(10.dp)
              )
              .clickable { selectedRate = rate }
              .padding(horizontal = 12.dp, vertical = 6.dp)
          ) {
            Text(
              text = "${rate.toInt()}% GST",
              fontSize = 11.sp,
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
              color = if (isSelected) Color.White else theme3D.textSecondary
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Intra-state vs Inter-state Toggle
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(10.dp))
          .background(theme3D.surface)
          .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
      ) {
        Box(
          modifier = Modifier
            .weight(1f)
            .clip(RoundedCornerShape(8.dp))
            .background(if (!isInterState) theme3D.primary.copy(alpha = 0.25f) else Color.Transparent)
            .border(
              1.dp,
              if (!isInterState) theme3D.primary else Color.Transparent,
              RoundedCornerShape(8.dp)
            )
            .clickable { isInterState = false }
            .padding(vertical = 8.dp),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = "Intra-State (Assam: CGST + SGST)",
            fontSize = 11.sp,
            fontWeight = if (!isInterState) FontWeight.Bold else FontWeight.Normal,
            color = if (!isInterState) Color.White else theme3D.textMuted
          )
        }

        Box(
          modifier = Modifier
            .weight(1f)
            .clip(RoundedCornerShape(8.dp))
            .background(if (isInterState) theme3D.secondary.copy(alpha = 0.25f) else Color.Transparent)
            .border(
              1.dp,
              if (isInterState) theme3D.secondary else Color.Transparent,
              RoundedCornerShape(8.dp)
            )
            .clickable { isInterState = true }
            .padding(vertical = 8.dp),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = "Inter-State (Outside: IGST)",
            fontSize = 11.sp,
            fontWeight = if (isInterState) FontWeight.Bold else FontWeight.Normal,
            color = if (isInterState) Color.White else theme3D.textMuted
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // 3D Result Breakdown Card
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(14.dp))
          .background(Color(0xFF070B12))
          .border(1.dp, theme3D.border, RoundedCornerShape(14.dp))
          .padding(14.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "TAX SUMMARY & JOURNAL BREAKDOWN",
            fontFamily = FontFamily.Monospace,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = theme3D.primaryLight
          )

          IconButton(
            onClick = {
              val summary = """
                Invoice Taxable: ₹$taxableAmount
                GST Rate: $selectedRate%
                ${if (!isInterState) "CGST: ₹$cgst\nSGST: ₹$sgst" else "IGST: ₹$igst"}
                Grand Total: ₹$grandTotal
                Prepared with Hemanta Dutta Tax Calculator
              """.trimIndent()
              clipboardManager.setText(AnnotatedString(summary))
              isCopied = true
            },
            modifier = Modifier.size(24.dp)
          ) {
            Icon(
              imageVector = if (isCopied) Icons.Default.Check else Icons.Default.ContentCopy,
              contentDescription = "Copy",
              tint = if (isCopied) theme3D.accent else theme3D.textSecondary,
              modifier = Modifier.size(16.dp)
            )
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text("Taxable Base Amount:", fontSize = 12.sp, color = theme3D.textSecondary)
          Text("₹${String.format(Locale.US, "%,.2f", taxableAmount)}", fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.SemiBold)
        }

        if (!isInterState) {
          Spacer(modifier = Modifier.height(6.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("CGST (${selectedRate / 2}%):", fontSize = 12.sp, color = theme3D.textMuted)
            Text("₹${String.format(Locale.US, "%,.2f", cgst)}", fontSize = 12.sp, color = theme3D.primaryLight)
          }
          Spacer(modifier = Modifier.height(4.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("SGST (${selectedRate / 2}%):", fontSize = 12.sp, color = theme3D.textMuted)
            Text("₹${String.format(Locale.US, "%,.2f", sgst)}", fontSize = 12.sp, color = theme3D.primaryLight)
          }
        } else {
          Spacer(modifier = Modifier.height(6.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("IGST ($selectedRate%):", fontSize = 12.sp, color = theme3D.secondary)
            Text("₹${String.format(Locale.US, "%,.2f", igst)}", fontSize = 12.sp, color = theme3D.secondary)
          }
        }

        Spacer(modifier = Modifier.height(8.dp))
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(1.dp)
            .background(theme3D.border)
        )
        Spacer(modifier = Modifier.height(8.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text("Total Invoice Payable:", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
          Text(
            "₹${String.format(Locale.US, "%,.2f", grandTotal)}",
            fontSize = 16.sp,
            fontWeight = FontWeight.Black,
            color = theme3D.accent
          )
        }
      }
    }
  }
}
