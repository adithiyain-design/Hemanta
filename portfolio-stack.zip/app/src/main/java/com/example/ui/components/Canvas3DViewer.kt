package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cached
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PointMode
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.LocalTheme3D
import com.example.ui.theme.Theme3DConfig
import kotlin.math.cos
import kotlin.math.sin

data class Vertex3D(val x: Float, val y: Float, val z: Float)
data class Face3D(val indices: List<Int>, val baseColor: Color, val label: String = "")

enum class Shape3DType(val displayName: String) {
  FINANCIAL_CUBE("3D Financial Cube"),
  MILESTONE_CRYSTAL("Career Crystal"),
  ACCOUNTING_COIN("Tax Hex-Prism")
}

@Composable
fun Interactive3DHeroSection(
  modifier: Modifier = Modifier,
  title: String = "Interactive 3D Portfolio Matrix",
  subtitle: String = "Touch & Drag to Rotate in 360° Space"
) {
  val theme3D = LocalTheme3D.current
  var selectedShape by remember { mutableStateOf(Shape3DType.FINANCIAL_CUBE) }
  var manualYaw by remember { mutableFloatStateOf(0.45f) }
  var manualPitch by remember { mutableFloatStateOf(0.35f) }
  var autoRotate by remember { mutableStateOf(true) }
  var wireframeOnly by remember { mutableStateOf(false) }
  var depthScale by remember { mutableFloatStateOf(1.0f) }

  val infiniteTransition = rememberInfiniteTransition(label = "360_rotation")
  val autoYawAngle by infiniteTransition.animateFloat(
    initialValue = 0f,
    targetValue = (Math.PI * 2).toFloat(),
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 14000, easing = LinearEasing),
      repeatMode = RepeatMode.Restart
    ),
    label = "auto_yaw"
  )

  val effectiveYaw = if (autoRotate) manualYaw + autoYawAngle else manualYaw
  val effectivePitch = manualPitch

  Column(
    modifier = modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(20.dp))
      .background(
        Brush.verticalGradient(
          listOf(
            theme3D.surfaceCard,
            theme3D.surface
          )
        )
      )
      .border(
        1.dp,
        Brush.horizontalGradient(
          listOf(theme3D.primary.copy(alpha = 0.5f), theme3D.secondary.copy(alpha = 0.5f))
        ),
        RoundedCornerShape(20.dp)
      )
      .padding(16.dp)
  ) {
    // Header row
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
          modifier = Modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(theme3D.primary.copy(alpha = 0.2f)),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.ViewInAr,
            contentDescription = "3D Icon",
            tint = theme3D.primaryLight,
            modifier = Modifier.size(20.dp)
          )
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column {
          Text(
            text = title,
            style = MaterialTheme.typography.titleMedium.copy(
              fontWeight = FontWeight.Bold,
              color = Color.White
            )
          )
          Text(
            text = subtitle,
            style = MaterialTheme.typography.bodySmall.copy(color = theme3D.textSecondary)
          )
        }
      }

      Surface(
        shape = RoundedCornerShape(12.dp),
        color = theme3D.surface,
        border = androidx.compose.foundation.BorderStroke(1.dp, theme3D.primary.copy(alpha = 0.4f))
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box(
            modifier = Modifier
              .size(6.dp)
              .clip(CircleShape)
              .background(if (autoRotate) theme3D.accent else Color.Gray)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = if (autoRotate) "60 FPS • LIVE" else "PAUSED",
            fontFamily = FontFamily.Monospace,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = if (autoRotate) theme3D.accent else theme3D.textMuted
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    // 3D Model Shape Selector Chips
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .horizontalScroll(rememberScrollState()),
      horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
      Shape3DType.values().forEach { shape ->
        val isSelected = selectedShape == shape
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) theme3D.primary.copy(alpha = 0.25f) else theme3D.surface)
            .border(
              1.dp,
              if (isSelected) theme3D.primary else theme3D.border,
              RoundedCornerShape(8.dp)
            )
            .padding(horizontal = 10.dp, vertical = 5.dp)
        ) {
          Text(
            text = shape.displayName,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            color = if (isSelected) Color.White else theme3D.textSecondary
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(12.dp))

    // Interactive 3D Canvas Box with touch gestures
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .height(260.dp)
        .clip(RoundedCornerShape(16.dp))
        .background(theme3D.background)
        .border(1.dp, theme3D.border, RoundedCornerShape(16.dp))
        .pointerInput(Unit) {
          detectDragGestures(
            onDragStart = { autoRotate = false },
            onDrag = { change, dragAmount ->
              change.consume()
              manualYaw += dragAmount.x * 0.012f
              manualPitch = (manualPitch - dragAmount.y * 0.012f).coerceIn(-1.3f, 1.3f)
            }
          )
        }
        .testTag("interactive_3d_viewport")
    ) {
      Canvas(modifier = Modifier.fillMaxSize()) {
        drawUnified3DModel(
          shapeType = selectedShape,
          yaw = effectiveYaw,
          pitch = effectivePitch,
          depthScale = depthScale,
          wireframe = wireframeOnly,
          theme3D = theme3D
        )
      }

      // 3D HUD Telemetry Overlay
      Column(
        modifier = Modifier
          .align(Alignment.TopStart)
          .padding(10.dp)
          .clip(RoundedCornerShape(8.dp))
          .background(Color.Black.copy(alpha = 0.65f))
          .border(1.dp, theme3D.border, RoundedCornerShape(8.dp))
          .padding(horizontal = 8.dp, vertical = 6.dp)
      ) {
        Text(
          text = "THEME: ${theme3D.name}",
          fontFamily = FontFamily.Monospace,
          fontSize = 9.sp,
          fontWeight = FontWeight.Bold,
          color = theme3D.primaryLight
        )
        Text(
          text = "YAW: ${(Math.toDegrees(effectiveYaw.toDouble()) % 360).toInt()}° | PITCH: ${Math.toDegrees(effectivePitch.toDouble()).toInt()}°",
          fontFamily = FontFamily.Monospace,
          fontSize = 9.sp,
          color = theme3D.textSecondary
        )
        Text(
          text = "MODEL: ${selectedShape.displayName}",
          fontFamily = FontFamily.Monospace,
          fontSize = 9.sp,
          color = theme3D.accent
        )
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    // Control bar (Auto-orbit, Wireframe, Reset Camera)
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        AssistChip(
          onClick = { autoRotate = !autoRotate },
          label = {
            Text(
              if (autoRotate) "Auto Orbit: On" else "Auto Orbit: Off",
              fontSize = 11.sp,
              color = if (autoRotate) theme3D.primaryLight else theme3D.textSecondary
            )
          },
          border = AssistChipDefaults.assistChipBorder(
            borderColor = if (autoRotate) theme3D.primary else theme3D.border,
            enabled = true
          )
        )

        AssistChip(
          onClick = { wireframeOnly = !wireframeOnly },
          label = {
            Text(
              if (wireframeOnly) "Wireframe: On" else "Solid 3D",
              fontSize = 11.sp,
              color = if (wireframeOnly) theme3D.secondary else theme3D.textSecondary
            )
          },
          border = AssistChipDefaults.assistChipBorder(
            borderColor = if (wireframeOnly) theme3D.secondary else theme3D.border,
            enabled = true
          )
        )
      }

      IconButton(
        onClick = {
          manualYaw = 0.45f
          manualPitch = 0.35f
          depthScale = 1.0f
          autoRotate = true
        },
        colors = IconButtonDefaults.iconButtonColors(contentColor = theme3D.textSecondary),
        modifier = Modifier.size(36.dp)
      ) {
        Icon(
          imageVector = Icons.Default.Cached,
          contentDescription = "Reset Camera",
          modifier = Modifier.size(18.dp)
        )
      }
    }

    // Depth & Perspective slider
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(top = 2.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Icon(
        imageVector = Icons.Default.ZoomIn,
        contentDescription = "Depth",
        tint = theme3D.textMuted,
        modifier = Modifier.size(18.dp)
      )
      Spacer(modifier = Modifier.width(8.dp))
      Text(
        text = "3D Camera Depth",
        fontSize = 12.sp,
        color = theme3D.textSecondary,
        modifier = Modifier.width(115.dp)
      )
      Slider(
        value = depthScale,
        onValueChange = { depthScale = it },
        valueRange = 0.6f..1.5f,
        modifier = Modifier.weight(1f),
        colors = SliderDefaults.colors(
          thumbColor = theme3D.primary,
          activeTrackColor = theme3D.primary,
          inactiveTrackColor = theme3D.surface
        )
      )
    }
  }
}

private fun DrawScope.drawUnified3DModel(
  shapeType: Shape3DType,
  yaw: Float,
  pitch: Float,
  depthScale: Float,
  wireframe: Boolean,
  theme3D: Theme3DConfig
) {
  val centerX = size.width / 2f
  val centerY = size.height / 2f
  val baseRadius = (minOf(size.width, size.height) * 0.36f) * depthScale
  val perspective = 520f

  // 3D Ambient Space Glow
  drawCircle(
    brush = Brush.radialGradient(
      colors = listOf(theme3D.primary.copy(alpha = 0.16f), Color.Transparent),
      center = Offset(centerX, centerY),
      radius = baseRadius * 1.8f
    )
  )

  // 3D Perspective Grid Plane
  drawPerspectiveGrid(centerX, centerY, baseRadius, pitch, yaw, theme3D.gridColor)

  val (rawVertices, faces) = when (shapeType) {
    Shape3DType.FINANCIAL_CUBE -> generateFinancialCubeGeometry(baseRadius, theme3D)
    Shape3DType.MILESTONE_CRYSTAL -> generateMilestoneCrystalGeometry(baseRadius, theme3D)
    Shape3DType.ACCOUNTING_COIN -> generateHexPrismGeometry(baseRadius, theme3D)
  }

  // 3D Rotation Math (Euler angles)
  val cosY = cos(yaw)
  val sinY = sin(yaw)
  val cosP = cos(pitch)
  val sinP = sin(pitch)

  // Transform vertices to 3D Camera & Screen Space
  val transformed = rawVertices.map { v ->
    // Rotate Yaw (around Y axis)
    val x1 = v.x * cosY + v.z * sinY
    val z1 = -v.x * sinY + v.z * cosY
    // Rotate Pitch (around X axis)
    val y2 = v.y * cosP - z1 * sinP
    val z2 = v.y * sinP + z1 * cosP

    // Perspective projection
    val cameraZ = perspective + z2
    val safeCameraZ = if (cameraZ < 60f) 60f else cameraZ
    val factor = perspective / safeCameraZ

    val screenX = centerX + x1 * factor
    val screenY = centerY + y2 * factor

    Triple(screenX, screenY, z2)
  }

  // Painters algorithm: sort faces by deepest Z
  val sortedFaces = faces.map { face ->
    val avgZ = face.indices.map { transformed[it].third }.average().toFloat()
    Pair(face, avgZ)
  }.sortedBy { it.second }

  // Render 3D Faces
  sortedFaces.forEach { (face, avgZ) ->
    val p1 = transformed[face.indices[0]]
    val p2 = transformed[face.indices[1]]
    val p3 = transformed[face.indices[2]]

    // Face normal for lighting
    val v1x = p2.first - p1.first
    val v1y = p2.second - p1.second
    val v2x = p3.first - p1.first
    val v2y = p3.second - p1.second
    val normalZ = v1x * v2y - v1y * v2x

    val path = Path().apply {
      moveTo(p1.first, p1.second)
      for (i in 1 until face.indices.size) {
        val pt = transformed[face.indices[i]]
        lineTo(pt.first, pt.second)
      }
      close()
    }

    val lightIntensity = if (normalZ > 0) {
      0.45f + (avgZ / (baseRadius * 1.6f)).coerceIn(-0.15f, 0.45f)
    } else {
      0.18f
    }

    if (!wireframe) {
      drawPath(
        path = path,
        color = face.baseColor.copy(alpha = lightIntensity.coerceIn(0.12f, 0.88f)),
        style = Fill
      )
    }

    // 3D Specular glowing edge
    drawPath(
      path = path,
      brush = Brush.linearGradient(
        colors = listOf(theme3D.primaryLight, theme3D.secondary),
        start = Offset(p1.first, p1.second),
        end = Offset(p3.first, p3.second)
      ),
      style = Stroke(
        width = if (wireframe) 1.8f else 1.2f,
        cap = StrokeCap.Round,
        join = StrokeJoin.Round
      )
    )
  }

  // Glowing 3D Vertices
  val points = transformed.map { Offset(it.first, it.second) }
  drawPoints(
    points = points,
    pointMode = PointMode.Points,
    color = Color.White,
    strokeWidth = 6f,
    cap = StrokeCap.Round
  )
  drawPoints(
    points = points,
    pointMode = PointMode.Points,
    color = theme3D.primary,
    strokeWidth = 10f,
    cap = StrokeCap.Round
  )
}

private fun DrawScope.drawPerspectiveGrid(
  centerX: Float,
  centerY: Float,
  radius: Float,
  pitch: Float,
  yaw: Float,
  gridColor: Color
) {
  val groundY = centerY + radius * 1.1f
  val gridSpan = radius * 2.2f
  val steps = 6
  for (i in -steps..steps) {
    val xOffset = (i.toFloat() / steps) * gridSpan
    drawLine(
      color = gridColor,
      start = Offset(centerX + xOffset * 0.4f, groundY - 30f),
      end = Offset(centerX + xOffset * 1.3f, groundY + 40f),
      strokeWidth = 1f
    )
  }
}

private fun generateFinancialCubeGeometry(
  radius: Float,
  theme3D: Theme3DConfig
): Pair<List<Vertex3D>, List<Face3D>> {
  val s = radius * 0.65f
  val vertices = listOf(
    Vertex3D(-s, -s, -s), // 0
    Vertex3D(s, -s, -s),  // 1
    Vertex3D(s, s, -s),   // 2
    Vertex3D(-s, s, -s),  // 3
    Vertex3D(-s, -s, s),  // 4
    Vertex3D(s, -s, s),   // 5
    Vertex3D(s, s, s),    // 6
    Vertex3D(-s, s, s)    // 7
  )

  val colors = theme3D.modelFaceColors
  val faces = listOf(
    Face3D(listOf(4, 5, 6, 7), colors.getOrElse(0) { theme3D.primary }, "Front: Tally & Accounting"),
    Face3D(listOf(1, 0, 3, 2), colors.getOrElse(1) { theme3D.secondary }, "Back: Ezy Rakod & Tax"),
    Face3D(listOf(0, 4, 7, 3), colors.getOrElse(2) { theme3D.accent }, "Left: B.Com Honors"),
    Face3D(listOf(5, 1, 2, 6), colors.getOrElse(3) { theme3D.primaryLight }, "Right: Nestle Sales"),
    Face3D(listOf(3, 2, 6, 7), colors.getOrElse(4) { theme3D.borderGlow }, "Top: GST Filing"),
    Face3D(listOf(0, 1, 5, 4), colors.getOrElse(5) { theme3D.primary }, "Bottom: Hardware & DTP")
  )
  return Pair(vertices, faces)
}

private fun generateMilestoneCrystalGeometry(
  radius: Float,
  theme3D: Theme3DConfig
): Pair<List<Vertex3D>, List<Face3D>> {
  val r = radius * 0.75f
  val h = radius * 0.92f

  val vertices = listOf(
    Vertex3D(0f, -h, 0f),                 // 0: Top Apex
    Vertex3D(r, -h * 0.2f, 0f),          // 1
    Vertex3D(r * 0.5f, -h * 0.2f, r * 0.866f), // 2
    Vertex3D(-r * 0.5f, -h * 0.2f, r * 0.866f),// 3
    Vertex3D(-r, -h * 0.2f, 0f),         // 4
    Vertex3D(-r * 0.5f, -h * 0.2f, -r * 0.866f),// 5
    Vertex3D(r * 0.5f, -h * 0.2f, -r * 0.866f), // 6
    Vertex3D(0f, h, 0f)                  // 7: Bottom Apex
  )

  val colors = theme3D.modelFaceColors
  val faces = listOf(
    Face3D(listOf(0, 1, 2), colors.getOrElse(0) { theme3D.primary }),
    Face3D(listOf(0, 2, 3), colors.getOrElse(1) { theme3D.secondary }),
    Face3D(listOf(0, 3, 4), colors.getOrElse(2) { theme3D.accent }),
    Face3D(listOf(0, 4, 5), colors.getOrElse(3) { theme3D.primaryLight }),
    Face3D(listOf(0, 5, 6), colors.getOrElse(4) { theme3D.secondary }),
    Face3D(listOf(0, 6, 1), colors.getOrElse(5) { theme3D.primary }),
    Face3D(listOf(7, 2, 1), colors.getOrElse(0) { theme3D.primary }),
    Face3D(listOf(7, 3, 2), colors.getOrElse(1) { theme3D.secondary }),
    Face3D(listOf(7, 4, 3), colors.getOrElse(2) { theme3D.accent }),
    Face3D(listOf(7, 5, 4), colors.getOrElse(3) { theme3D.primaryLight }),
    Face3D(listOf(7, 6, 5), colors.getOrElse(4) { theme3D.secondary }),
    Face3D(listOf(7, 1, 6), colors.getOrElse(5) { theme3D.primary })
  )
  return Pair(vertices, faces)
}

private fun generateHexPrismGeometry(
  radius: Float,
  theme3D: Theme3DConfig
): Pair<List<Vertex3D>, List<Face3D>> {
  val r = radius * 0.7f
  val halfH = radius * 0.35f
  val vertices = mutableListOf<Vertex3D>()

  // Top hexagon ring (0..5)
  for (i in 0 until 6) {
    val angle = (i * Math.PI / 3.0).toFloat()
    vertices.add(Vertex3D(r * cos(angle), -halfH, r * sin(angle)))
  }
  // Bottom hexagon ring (6..11)
  for (i in 0 until 6) {
    val angle = (i * Math.PI / 3.0).toFloat()
    vertices.add(Vertex3D(r * cos(angle), halfH, r * sin(angle)))
  }

  val faces = mutableListOf<Face3D>()
  val colors = theme3D.modelFaceColors

  // Side rectangular faces
  for (i in 0 until 6) {
    val next = (i + 1) % 6
    faces.add(
      Face3D(
        listOf(i, next, next + 6, i + 6),
        colors.getOrElse(i % colors.size) { theme3D.primary }
      )
    )
  }

  // Top cap
  faces.add(Face3D(listOf(0, 1, 2, 3, 4, 5), theme3D.primary))
  // Bottom cap
  faces.add(Face3D(listOf(11, 10, 9, 8, 7, 6), theme3D.secondary))

  return Pair(vertices, faces)
}
