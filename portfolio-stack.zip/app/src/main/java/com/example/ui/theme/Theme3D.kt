package com.example.ui.theme

import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

data class Theme3DConfig(
  val id: String,
  val name: String,
  val tagLine: String,
  val primary: Color,
  val primaryLight: Color,
  val secondary: Color,
  val accent: Color,
  val background: Color,
  val surface: Color,
  val surfaceCard: Color,
  val border: Color,
  val borderGlow: Color,
  val textPrimary: Color = Color(0xFFF8FAFC),
  val textSecondary: Color = Color(0xFF94A3B8),
  val textMuted: Color = Color(0xFF64748B),
  val cubeGradient: List<Color>,
  val modelFaceColors: List<Color>,
  val gridColor: Color
) {
  val heroGradient: Brush
    get() = Brush.horizontalGradient(listOf(primary, secondary))

  val cardGradient: Brush
    get() = Brush.verticalGradient(listOf(surfaceCard, surface))
}

object Theme3DPresets {
  val CYBER_OBSIDIAN = Theme3DConfig(
    id = "cyber_obsidian",
    name = "Cyber Obsidian 3D",
    tagLine = "Holographic Neon & Deep Space Void",
    primary = Color(0xFF38BDF8),
    primaryLight = Color(0xFF7DD3FC),
    secondary = Color(0xFF818CF8),
    accent = Color(0xFF34D399),
    background = Color(0xFF060911),
    surface = Color(0xFF0D1424),
    surfaceCard = Color(0xFF131D33),
    border = Color(0xFF1E2E4E),
    borderGlow = Color(0x6638BDF8),
    cubeGradient = listOf(Color(0xFF38BDF8), Color(0xFF818CF8), Color(0xFFF472B6)),
    modelFaceColors = listOf(
      Color(0xFF0284C7),
      Color(0xFF38BDF8),
      Color(0xFF6366F1),
      Color(0xFF818CF8),
      Color(0xFFEC4899),
      Color(0xFF06B6D4)
    ),
    gridColor = Color(0x2238BDF8)
  )

  val EMERALD_LEDGER = Theme3DConfig(
    id = "emerald_ledger",
    name = "Emerald Ledger 3D",
    tagLine = "Bespoke Accounting & Financial Luxury",
    primary = Color(0xFF10B981),
    primaryLight = Color(0xFF6EE7B7),
    secondary = Color(0xFFF59E0B),
    accent = Color(0xFF34D399),
    background = Color(0xFF030D0A),
    surface = Color(0xFF071B15),
    surfaceCard = Color(0xFF0D2921),
    border = Color(0xFF164438),
    borderGlow = Color(0x6610B981),
    cubeGradient = listOf(Color(0xFF10B981), Color(0xFFF59E0B), Color(0xFF34D399)),
    modelFaceColors = listOf(
      Color(0xFF047857),
      Color(0xFF10B981),
      Color(0xFFD97706),
      Color(0xFFF59E0B),
      Color(0xFF059669),
      Color(0xFFFBBF24)
    ),
    gridColor = Color(0x2210B981)
  )

  val TITANIUM_SPATIAL = Theme3DConfig(
    id = "titanium_spatial",
    name = "Titanium Spatial 3D",
    tagLine = "Apple VisionOS Frosted Crystal Glass",
    primary = Color(0xFF60A5FA),
    primaryLight = Color(0xFF93C5FD),
    secondary = Color(0xFFCBD5E1),
    accent = Color(0xFF38BDF8),
    background = Color(0xFF0A0E17),
    surface = Color(0xFF131A26),
    surfaceCard = Color(0xFF1C2536),
    border = Color(0xFF2E3D56),
    borderGlow = Color(0x6660A5FA),
    cubeGradient = listOf(Color(0xFF60A5FA), Color(0xFFCBD5E1), Color(0xFF38BDF8)),
    modelFaceColors = listOf(
      Color(0xFF1D4ED8),
      Color(0xFF60A5FA),
      Color(0xFF64748B),
      Color(0xFF94A3B8),
      Color(0xFF0284C7),
      Color(0xFFE2E8F0)
    ),
    gridColor = Color(0x2260A5FA)
  )

  val SUNSET_HORIZON = Theme3DConfig(
    id = "sunset_horizon",
    name = "Sunset Horizon 3D",
    tagLine = "Cyberpunk Amber & Volumetric Dusk",
    primary = Color(0xFFF43F5E),
    primaryLight = Color(0xFFFDA4AF),
    secondary = Color(0xFFF97316),
    accent = Color(0xFFA855F7),
    background = Color(0xFF0D0613),
    surface = Color(0xFF180D24),
    surfaceCard = Color(0xFF251538),
    border = Color(0xFF3D235C),
    borderGlow = Color(0x66F43F5E),
    cubeGradient = listOf(Color(0xFFF43F5E), Color(0xFFF97316), Color(0xFFA855F7)),
    modelFaceColors = listOf(
      Color(0xFFE11D48),
      Color(0xFFF43F5E),
      Color(0xFFEA580C),
      Color(0xFFF97316),
      Color(0xFF9333EA),
      Color(0xFFFB7185)
    ),
    gridColor = Color(0x22F43F5E)
  )

  val ALL_THEMES = listOf(
    CYBER_OBSIDIAN,
    EMERALD_LEDGER,
    TITANIUM_SPATIAL,
    SUNSET_HORIZON
  )
}

val LocalTheme3D = compositionLocalOf { Theme3DPresets.CYBER_OBSIDIAN }
